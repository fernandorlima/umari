from django.conf.urls import include
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path
from django.contrib.auth import views as auth_views


from rest_framework.decorators import api_view
from rest_framework.routers import DefaultRouter
####################################################################################################
############   views
from .views import index, produto, home, MenuView,lista_menu, menu_detail, menu_create, lista_grupos,\
    menu_edit,menu_delete,mapa_mesas,lista_pedidos, cadastra_item_pedido, lista_menu01, adicionar_itens_selecionados,\
ListaMenu01View,  AdicionarItensSelecionadosView,Fechar_Comanda,lista_pedidos_pdf, imprimir_itens_detalhados,\
cadastra_mesa, lista_mesa, mesa_edit, mesa_delete, mesa_mudar, lista_cardapio, atualiza_itens_pedido, novo_item, lista_comandas,\
cadastra_comandas, MesasAbertas, pdv_view, Fechar_Pedidos, Fechar_Pedidos, Finaliza_Comanda, lista_comandas_mesa,\
    CaixaEntreDatasView, ficha_tecnica_create, altera_status_pedido, pega_quantidade, comandas_por_periodo,  item_comandas_por_periodo,\
ProdutoListView
#####################################################################################################
from .api_views import GrupoMenuViewSet, MenuViewSet, CoamandaViewSet, ItemcomandaVewSet, MessasViewSet, UserprofileViewSet, userViewSet
# rotas api
router = DefaultRouter()
router.register('grupos-menu', GrupoMenuViewSet, basename='grupo-menu')
router.register('menu', MenuViewSet, basename='menu')
router.register('comandas',CoamandaViewSet, basename='comandas')
router.register('item-comandas',ItemcomandaVewSet, basename='item-comandas')
router.register('usuarios',userViewSet, basename='usuarios')
router.register('userprofile',UserprofileViewSet, basename='userprofile')


urlpatterns = [
    path('admin/', admin.site.urls),
  #  path('', include('django.contrib.auth.urls')),
   # path('accounts/', include('django.contrib.auth.urls')),
    ################## logi#######################################
    path('', auth_views.LoginView.as_view(),name='login'),
   path('password_reset/', auth_views.PasswordResetView.as_view(), name="password_reset"),
   path('password_reset/done/', auth_views.PasswordResetDoneView.as_view(), name="password_reset_done"),
   path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(),name='password_reset_confirm'),
   path('reset/done/', auth_views.PasswordResetCompleteView.as_view(), name='password_reset_complete'),
                  ########################################################
 #   path('', home,  name ='home'),
    path('index', index, name = 'index'),
  path('produto',produto, name='produto'),
  path('Menu/produto_list.html/', ProdutoListView.as_view(), name='lista_produto'),
  path('produto_list', ProdutoListView.as_view(), name='lista_produto'),
    path('home',home,name='home'),
    path('Menu/menu',MenuView.as_view(), name='menu'),
    path('Menu/lista_menu/<int:id>', lista_menu, name='lista_menu'),
    path('Menu/lista_grupos', lista_grupos, name='grupos'),
    path('menu/<int:pk>/', menu_detail, name='menu_detail'),
    path('Menu/menu_create/', menu_create, name='menu_create'),
    path('Menu/menu_edite/<int:pk>/', menu_edit, name='menu_edit'),
    path('Menu/menu_delete/<int:pk>/', menu_delete, name='menu_delete'),
    path('Menu/mapa_mesas',mapa_mesas, name='mapa_mesas'),
    path('Menu/lista_pedido/<int:mesa_id>/', lista_pedidos, name='lista_pedido'),
    path('Menu/cadastra_item_pedido/<int:mesa_id>/', cadastra_item_pedido, name='cadastra_item_pedido'),
    path('Menu/lista_menu01', lista_menu01, name='lista_menu01'),
    path('Menu/lista_menu01', ListaMenu01View.as_view(), name='lista_menu01'),
    path('Menu/adicionar_itens_selecionados/', AdicionarItensSelecionadosView.as_view(),
         name='adicionar_itens_selecionados'),
    path('Menu/fechar_comandas/<int:mesa_id>/', Fechar_Comanda.as_view(), name='fechar_comanda'),
    path('fecha_pedido/<int:pk>/', Fechar_Pedidos, name='fecha_pedido'),
    path('lista_pedidos_pdf/<int:comanda>/',lista_pedidos_pdf, name='lista_pedidos_pdf'),
    path('imprimir_itens_detalhados/',imprimir_itens_detalhados, name='imprimir_itens_detalhados'),
   #  Mesas
    path('Menu/lista_mesa', lista_mesa, name='lista_mesa'),
    path('Menu/lista_comandas', lista_comandas, name='lista_comandas'),

    path('Menu/cadastra_mesa', cadastra_mesa, name='cadastra_mesa'),
    path('Menu/mesa_edit/<int:id>',mesa_edit, name='mesa_edit'),
    path('Menu/mesa_delete/<int:id>',mesa_delete, name='mesa_delete'),
    path('Menu/mesa_mudar/<int:id>', mesa_mudar,  name='mesa_mudar'),
    path('Menu/lista_cardapio/<int:id>', lista_cardapio, name='lista_cardapio'),
    path('atualiza_itens_pedido/<int:mesa_id>/', atualiza_itens_pedido, name='atualiza_itens_pedido'),
    path('novo_item/<int:menu_id>/<int:comanda>', novo_item, name='novo_item'),
    path('Menu/lista_comandas', lista_comandas, name='lista_comandas'),
    path('Menu/cadastra_comandas', cadastra_comandas, name='nova_comanda'),
 #   path('Menu/lista_comandas/', ComandaAbertaListView.as_view(), name='lista_comandas'),
   path('Menu/mesas_abertas_list/', MesasAbertas, name='comandas'),
    path('pdf_view', pdv_view, name='pdv_view' ),
    path('Fechar_Pedidos/<int:mesa_id>', Fechar_Pedidos, name='fechar_pedido'),
    path('finaliza_comanda/<int:mesa_id>/', Finaliza_Comanda, name='finaliza_comanda'),
   # path('Finaliza_Comanda/<int:mesa_id>, <str:pgto>,  <int:fpgto>', Finaliza_Comanda, name='finaliza_comanda'),
    path('lista_comandas_mesa/<int:mesa_id>/', lista_comandas_mesa, name='lista_comandas_mesa'),
   # path('listar_dados_caixa', listar_dados_caixa, name='listar_dados_caixa'),
    path('CaixaEntreDatasView', CaixaEntreDatasView.as_view(), name='caixaentredatas'),
   path('ficha_tecnica_create/<int:menu_id>/', ficha_tecnica_create, name='ficha_tecnica_create'),
    path('Menu/pega_quant/', pega_quantidade, name='pega_quant'),
    path('altera_status_pedido/', altera_status_pedido, name='altera_status_pedido'),
     path('comandas_por_periodo/', comandas_por_periodo, name='comandas_por_periodo'),
     path('CaixaEntreDatasView', CaixaEntreDatasView.as_view(), name='caixaentredatas'),
       path('item_comandas_por_periodo/', item_comandas_por_periodo, name='item_comandas_por_periodo'),
              ]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

