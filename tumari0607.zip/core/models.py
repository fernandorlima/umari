from django.db import models
from django.contrib.auth.models import User
from datetime import date
# Create your models here.
from django.shortcuts import redirect
from django.views.generic import View
from django.contrib import messages
from django import setup



class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)


    def __str__(self):
        return self.user.username


class Fornecedor(models.Model):

    STATUS_FORNEC = (
        ("F", "Pessoa Fisica"),
        ("J", "Pessoa Juridica"),
    )
    nome = models.CharField('Nome', max_length=80)
    endereco = models.CharField('Endereço', max_length=80)
    email   = models.EmailField('Email')
    fone = models.CharField('Fone', max_length=12)
    whatsapp = models.CharField('whatsApp', max_length=12)
    tipo = models.CharField('Tipo' ,max_length=1, choices=STATUS_FORNEC, default='')
    cpfcnpj = models.CharField('CPF/CNPJ', max_length=13)
    usuario = models.ForeignKey('UserProfile', on_delete=models.SET_NULL, null=True)


class Produto(models.Model):
    nome = models.CharField(max_length=80, verbose_name='Produto')
    quantidade = models.IntegerField(verbose_name='Quantidade')
    valor = models.DecimalField(decimal_places=2,max_digits=9 , verbose_name='Valor R$')
    data_cad  = models.DateField(auto_now=True, verbose_name='Data Cadastro')
    data_atu = models.DateField(auto_now=True, verbose_name='Data Atualização')
    grupo = models.ForeignKey('Grupos', on_delete=models.SET_NULL, null=True,verbose_name='Grupo')
    unidade = models.ForeignKey('Unidades', on_delete=models.SET_NULL, null=True,verbose_name='Apresentação')
    quant_unidade = models.IntegerField(verbose_name='Volumes')
    estoque_atual = models.IntegerField(verbose_name='Estoque Atual')
    estoque_min = models.IntegerField(verbose_name='Estoque Atual')

    usuario = models.ForeignKey('UserProfile', on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return self.nome

class Entradas(models.Model):
    produto = models.ForeignKey('Produto', on_delete=models.SET_NULL, null=True, verbose_name='Produto')
    entrada = models.IntegerField(verbose_name='Quantidade')
    fornecedor = models.ForeignKey('Fornecedor', on_delete=models.SET_NULL, null=True,verbose_name='Fornecedor' )
    preco   = models.DecimalField( max_digits=8, decimal_places=2,verbose_name='Valor R$')
    data_entrada = models.DateField(null=True,blank=True, verbose_name='Data Entrada')
    data_cad  = models.DateField(auto_now=True)
    usuario = models.ForeignKey('UserProfile', on_delete=models.SET_NULL, null=True)

class Saidas(models.Model):
      TIPO_SAIDA=(("1","Comanda"),
                ("2","Inventario"),
                ("3", "Estorno"),
                ("4","Saida")
                )
      produto = models.ForeignKey('Produto', on_delete=models.SET_NULL, null=True, verbose_name='Produto')
      saida = models.IntegerField(verbose_name='Quantidade')
      tipo_saida= models.CharField(max_length=1,choices=TIPO_SAIDA, default='1')

      data_saida = models.DateField(auto_now=True, verbose_name='Data Saida')
      data_cad  = models.DateField(auto_now=True)
      usuario = models.ForeignKey('UserProfile', on_delete=models.SET_NULL, null=True)

class Clientes(models.Model):
    nome     = models.CharField('Nome',max_length=80)
    endereco = models.CharField('Enrdereço',max_length=80)
    data_nasc = models.DateField('Data de NAscimento')
    email     = models.EmailField('email')
    data_cad = models.DateField(auto_now=True)
    usuario = models.ForeignKey('UserProfile', on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return f'{ self.nome }{self.email}'


class Unidades(models.Model):
    descricao = models.CharField(max_length=50)
    abrevia = models.CharField(max_length=10)
    data_cad = models.DateField(auto_now=True)
    usuario = models.ForeignKey('UserProfile', on_delete=models.SET_NULL, null=True)

    def __str__(self):
       """String for representing the Model object."""
       return self.abrevia

class Grupos(models.Model):
    descricao = models.CharField(max_length=80, help_text='Entre com um Grupo')
    imagem = models.ImageField(upload_to='media/imagem', null=True)
    usuario = models.ForeignKey('UserProfile', on_delete=models.SET_NULL, null=True)

    def __str__(self):
       """String for representing the Model object."""
       return self.descricao



class Mesas(models.Model):
    STATUS_MESA = (
         ("l", "Livre"),
         ("o", "Ocupada"),
         ("r", "Reservada"),
         ("b", "Bloqueada"),
    )
    descricao =models.CharField(max_length=50, null=False)
    status_mesa = models.CharField(max_length=1,choices=STATUS_MESA, default='l')
    data_cad = models.DateField(auto_now=True)
    usuario = models.ForeignKey('UserProfile', on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return self.descricao

class GrupoMenu(models.Model):

    descricao = models.TextField('Grupo', max_length=80)
    data_cad = models.DateField(auto_now=True)
    imagem = models.ImageField(upload_to='media/imagem', null=True)

    def __str__(self):
        return self.descricao

class Menu(models.Model):
    ft= ( ("S", "Sim"),
        ("N", "Não"),
    )
    ativo=(("S", "Sim"),
           ("N","Não")
           )
    grupomen = models.ForeignKey('GrupoMenu', on_delete=models.SET_NULL, null=True, verbose_name='Categoria')
    item_menu= models.CharField(max_length=80, null= False, verbose_name='Item')
    descricao = models.TextField(verbose_name='Descrição')
    porcao = models.CharField(max_length=20, verbose_name='Unidade')
    data_cad = models.DateField(auto_now=True, verbose_name='Data Cadastro')
    preco = models.DecimalField(max_digits=8, decimal_places=2, null=False, default=0.0, verbose_name='Preç R$')
    usuario = models.ForeignKey('UserProfile', on_delete=models.SET_NULL, null=True)
    imagem = models.ImageField(upload_to='media/imagem',  null=True)
    ficha_tecnica = models.CharField(max_length=1, choices=ft, default="N", verbose_name='Ficha Tecnica')
    ativo = models.CharField(max_length=1, choices=ft, default="S", verbose_name='Ativo')
    id_produto     = models.ForeignKey('Produto', on_delete=models.SET_NULL, null=True, verbose_name='Produto')

def __str__(self):
    return self.item_menu

class FichaTecnica(models.Model):
    menu=models.OneToOneField('Menu',on_delete=models.SET_NULL, null=True, verbose_name='Item de  Cardapio')
    ingredientes=models.ForeignKey('Produto', on_delete=models.SET_NULL, null=True, verbose_name='Ingrediente')
    quantidade = models.IntegerField( verbose_name='Quantidade')
    unidade    = models.ForeignKey('Unidades',  on_delete=models.SET_NULL, null=True, verbose_name='Unidade')
    preparo    = models.TextField(null= True)
    observacoes = models.CharField(max_length=50, verbose_name='Observação', null = True, default = '')



class Comanda(models.Model):
     STATUS_COMANDA = (
         ("a", "aberta"),
         ("f", "Fechada"),
       )
     descricao = models.CharField(max_length=50, null=False, verbose_name='Cliente')
     mesa = models.ForeignKey('Mesas', on_delete=models.SET_NULL, null=True, verbose_name='Local')
     usuario = models.ForeignKey('UserProfile', on_delete=models.SET_NULL, null=True)
     staus_comanda = models.CharField(max_length=1, choices=STATUS_COMANDA, default="a" )
     data_cad = models.DateField()
     hora_inicio = models.TimeField()
     hora_fim = models.TimeField()
     total_comanda = models.DecimalField(max_digits=8, decimal_places=2, null=False, default=0.0)
     usuario = models.ForeignKey('UserProfile', on_delete=models.SET_NULL, null=True)

class ItemComanda(models.Model):
    comanda = models.ForeignKey('Comanda', on_delete=models.SET_NULL, null=True)
    item_menu = models.ForeignKey('Menu', on_delete=models.SET_NULL, null=True)
    quantidade = models.IntegerField(4)
    status     = models.CharField(max_length=10,default='Preparo')
    observacao = models.CharField(max_length=80,  null=True)
    descicao_item = models.CharField(max_length=80,  null=True)
    usuario = models.ForeignKey('UserProfile', on_delete=models.SET_NULL, null=True)


######## caixa  #######




############### forma de pgto ####################

class FormaPgto(models.Model):
    nome =models.CharField(max_length=80)
    descricao= models.CharField(max_length=80)


########## contas a pagar ######

class ContasPagar(models.Model):
    id =  models.AutoField(primary_key=True)
    nome_conta = models.CharField(max_length=80)

class Conta(models.Model):
    """Representa uma conta a pagar."""

    id = models.AutoField(primary_key=True)
    titulo = models.ForeignKey(ContasPagar, on_delete=models.CASCADE)
    valor = models.DecimalField(max_digits=10, decimal_places=2)
    vencimento = models.DateField()
    status = models.CharField(max_length=20, choices=[
        ('Aberto', 'Aberto'),
        ('Pago', 'Pago'),
        ('Vencido', 'Vencido'),
    ])
    usuario = models.ForeignKey('UserProfile', on_delete=models.SET_NULL, null=True)


class Pagamento(models.Model):
    """Representa um pagamento de uma conta."""

    id = models.AutoField(primary_key=True)
    conta_id = models.ForeignKey(Conta, on_delete=models.CASCADE)
    valor = models.DecimalField(max_digits=10, decimal_places=2)
    data_pagamento = models.DateField()
    observacao = models.CharField(max_length=200)
    usuario = models.ForeignKey('UserProfile', on_delete=models.SET_NULL, null=True)

class Caixa(models.Model):
        valor = models.DecimalField(max_digits=10, decimal_places=2)
        tipo = models.ForeignKey('TipoMovimento', on_delete=models.CASCADE)
        descricao = models.CharField(max_length=255)
        forma_pgto_caixa = models.ForeignKey(FormaPgto, on_delete=models.CASCADE)
        # Data e hora da movimentação
        data = models.DateTimeField()
        usuario = models.ForeignKey('UserProfile', on_delete=models.SET_NULL, null=True)





class TipoMovimento(models.Model):
    nome = models.CharField(max_length=30)




