from django.shortcuts import get_object_or_404  # busca objeto se não encontrar traz p erro 404
from django.http import HttpResponse
from django.contrib import messages
from django.shortcuts import render, redirect
from .models import UserProfile, Menu, Produto, Mesas, Grupos, ItemComanda, Comanda, Caixa, TipoMovimento, FormaPgto
from django.views import generic
from django.views.decorators.csrf import csrf_protect
from django.contrib.auth.decorators import login_required
from .forms import CadastroItemPedidoForm, MenuForm, MenuDeleteForm, MesasForm, MesasDeleteForm, ComandasForm, PDVForm
from datetime import datetime, date, time
from django.db.models import Q
from decimal import Decimal
from django.http import JsonResponse
from django.views.generic import TemplateView
from django.views import View
from django.views.generic import ListView
from django.http import JsonResponse
from django.utils import timezone  # Ensure timezone is imported
import os


# Create your views here.
# viewlist class-basead que gera uma lista do modelo Menu
class MenuView(generic.ListView):
    model = Menu
    template_name = 'Menu/lista_menu.html'
    context_object_name = 'menus'  # your own name for the list as a template variable
    queryset = Menu.objects.all
    lista_menu = 'Menu/lista_menu.html'  # Specify your own template name/location


@login_required
def home(request):
    return (render(request, 'home.html'))


@csrf_protect
def index(request):
    return (render(request, 'index.html'))


@login_required
def produto(request, id):
    vproduto = Produto.objects.get(pk=id)
    prod = get_object_or_404(Produto, pk=id)
    context = {'produto': vproduto}
    return (render(request, 'produto.html', context))


@login_required
def listagrupos(request):
    listagrupos = Grupos.objects.all()
    context = {'grupos': listagrupos}
    return (render(request, 'listagrupos.html', context))


# formularios  crud menu


def lista_menu(request):
    query = request.GET.get('q', '')

    menus = Menu.objects.filter(
        Q(descricao__icontains=query) | Q(grupomen__descricao__icontains=query)).order_by('grupomen__descricao',
                                                                                          'item_menu')

    return render(request, 'Menu\lista_menu.html', {'menus': menus, 'query': query})


################################

def lista_menu01(request):
    query = request.GET.get('q', '')

    menus = Menu.objects.filter(
        Q(descricao__icontains=query) | Q(grupomen__descricao__icontains=query)).order_by('grupomen__descricao',
                                                                                          'item_menu')

    return render(request, 'Menu\lista_menu01.html', {'menus': menus, 'query': query})


####################################


def menu_detail(request, pk):
    menu = get_object_or_404(Menu, pk=pk)
    return render(request, 'menu_detail.html', {'menu': menu})


@login_required
def menu_create(request):
    if request.method == 'POST':
        form = MenuForm(request.POST)
        if form.is_valid():
            # Crie uma instância de Menu usando o form
            menu = form.save(commit=False)

            # Associe o usuário ao menu
            if not hasattr(request.user, 'userprofile'):
                UserProfile.objects.create(user=request.user)  # Cria o UserProfile

            usuario_perfil = request.user.userprofile
            menu.usuario = usuario_perfil

            # Salve o menu no banco de dados
            menu.save()

            # Adicione a mensagem de sucesso
            messages.success(request, 'Operação realizada com sucesso!')

            # Redirecione para a mesma página de inclusão
            return redirect('menu_create')
    else:
        form = MenuForm()

    return render(request, 'Menu/menu_create.html', {'form': form})


def menu_edit(request, pk):
    menu = get_object_or_404(Menu, pk=pk)

    if request.method == 'POST':
        form = MenuForm(request.POST, instance=menu)
        if form.is_valid():
            menu = form.save()
            return redirect('menu_edit', pk=menu.pk)  # Correção aqui
    else:
        form = MenuForm(instance=menu)

    return render(request, 'Menu/menu_edit.html', {'form': form})


def menu_delete(request, pk):
    menu = get_object_or_404(Menu, pk=pk)

    if request.method == 'POST':
        form = MenuDeleteForm(request.POST)
        if form.is_valid() and form.cleaned_data['confirm_delete']:
            menu.delete()
            messages.success(request, 'Operação realizada com sucesso!')
            return redirect('lista_menu')  # Substitua 'alguma_view' pela view apropriada após a exclusão
    else:
        form = MenuDeleteForm()

    return render(request, 'Menu\menu_delete.html', {'form': form, 'menu': menu})


def mapa_mesas(request):
    mesas = Mesas.objects.all()
    return render(request, 'Menu\mapa_mesas.html', {'mesas': mesas})


# pedidos

def lista_pedidos(request, mesa_id):
    try:
        # Obtém a comanda associada à mesa
        comanda = Comanda.objects.get(mesa_id=mesa_id, staus_comanda='a')
        comanda_num= comanda.id



        # Obtém os itens da comanda associada à mesa, incluindo informações do item_menu
        itens_comanda = ItemComanda.objects.filter(comanda=comanda)

        # Inicializa variáveis para o valor total e lista de itens com detalhes
        valor_total_comanda = 0
        itens_detalhados = []

        # Calcula o total por item e o valor total da comanda
        for item in itens_comanda:

            descricao_item_menu = item.item_menu.item_menu
            preco_item_menu = item.item_menu.preco
            quantidade_item_comanda = item.quantidade
            total_por_item = preco_item_menu * quantidade_item_comanda

            # Adiciona detalhes do item ao total
            itens_detalhados.append({
                'descricao': descricao_item_menu,
                'preco_unitario': preco_item_menu,
                'quantidade': quantidade_item_comanda,
                'total_por_item': total_por_item,
            })

            # Atualiza o valor total da comanda
            valor_total_comanda += total_por_item

        return render(request, 'Menu\lista_pedido.html',
                      {'itens_detalhados': itens_detalhados,
                       'valor_total_comanda': valor_total_comanda, 'Mesa': mesa_id, 'comanda_num':comanda_num})

    except Comanda.DoesNotExist:
        return render(request, 'Menu\lista_pedido.html',
                      {'mensagem': 'Não existe comanda para esta Mesa', 'Mesa': mesa_id})


def cadastra_item_pedido(request, mesa_id):
    if request.method == 'PFOST':
        form = CadastroItemPedidoForm(request.POST)
        if form.is_valid():
            item_pedido = form.save(commit=True)

            # Verificar se a comanda já existe
            comanda, created = Comanda.objects.get_or_create(
                mesa_id=mesa_id,
                staus_comanda='a',  # Corrigi o status da comanda
                defaults={'data_cad': date.today(), 'hora_inicio': datetime.now().time()}
            )

            # Se a comanda foi criada, a mesa associada está disponível em comanda.mesa
            mesa = comanda.mesa

            # Se a comanda não foi criada, criamos a mesa agora
            if created:
                mesa, _ = Mesas.objects.get_or_create(id=mesa_id, defaults={'status_mesa': 'o'})

            # Associar o item do pedido à comanda
            item_pedido.comanda = comanda

            # Salvar o item do pedido
            item_pedido.save()

            # Atualizar status da mesa e comanda
            mesa.status_mesa = 'o'
            mesa.save()

            comanda.staus_comanda = 'a'
            comanda.save()

            return redirect('Menu/lista_pedido', mesa_id=mesa_id)
    else:
        form = CadastroItemPedidoForm()

    return render(request, 'Menu\cadastra_item_pedido.html', {'form': form, 'mesa_id': mesa_id})


def adicionar_itens_selecionados(request):
    if request.method == 'POST':
        selected_items = request.POST.getlist('selected_items')

        # Inicialize a lista de itens_pedido na sessão se ainda não existir
        if 'itens_pedido' not in request.session:
            request.session['itens_pedido'] = []

        # Adicione os itens selecionados à lista na sessão
        for menu_id in selected_items:
            menu = Menu.objects.get(id=menu_id)
            request.session['itens_pedido'].append({
                'item_menu': menu.item_menu,
                'descricao': menu.descricao,
                'preco': float(menu.preco),
                'porcao': menu.porcao,
            })

        # Redirecione para a página lista_menu01 após o processamento
        return redirect('lista_menu01')

    return JsonResponse({'error': 'Método não permitido'}, status=405)


class ListaMenu01View(View):
    template_name = 'lista_menu01.html'  # Substitua 'seu_template.html' pelo nome do seu template

    def get(self, request, *args, **kwargs):
        # Obtenha os itens do pedido da sessão
        pedidos = request.session.get('itens_pedido', [])

        # Adicione qualquer lógica adicional conforme necessário

        # Renderize a página com os itens do pedido
        return render(request, self.template_name, {'pedidos': pedidos})


class AdicionarItensSelecionadosView(View):
    template_name = 'Menu/lista_menu01.html'

    def post(self, request, *args, **kwargs):
        if 'selected_items' in request.POST:
            selected_items = request.POST.getlist('selected_items')

            # Add selected items to the session
            if 'itens_pedido' not in request.session:
                request.session['itens_pedido'] = []
            request.session['itens_pedido'].extend([
                Menu.objects.get(id=menu_id) for menu_id in selected_items
            ])

        # Render the template with updated context
        menus = Menu.objects.all()
        pedidos = request.session.get('itens_pedido', [])
        return render(request, self.template_name, {'menus': menus, 'pedidos': pedidos})

    def get(self, request, *args, **kwargs):
        menus = Menu.objects.all()
        pedidos = request.session.get('itens_pedido', [])
        return render(request, self.template_name, {'menus': menus, 'pedidos': pedidos})


class Fechar_Comanda(View):
    def post(self, request, mesa_id):
        mesa = Mesas.objects.get(id=mesa_id)
        comanda = Comanda.objects.get(mesa=mesa)
#
        # Altere o status da mesa para 'l'
        mesa.status_mesa = 'l'
        mesa.save()

        # Altere o status da comanda para 'f'
        comanda.staus_comanda = 'f'
        comanda.hora_fim = timezone.now()  # Adicione a hora de fechamento
        comanda.save()

        # Mostre a mensagem
        messages.success(request, 'Comanda fechada com sucesso')

        return redirect('lista_pedidos')  # Retornando para a página de lista de pedidos


def fecha_pedido(request, pk, pgto, fpgto):
    mesa = Mesas.objects.get(id=pk)
    mesa.status_mesa = 'l'
    mesa.save()
    # atualiza comandas
    comanda = Comanda.objects.get(mesa=mesa, staus_comanda='a')
    comanda.staus_comanda = 'f'
    comanda.hora_fim = timezone.now()

    comanda.save()
# atualuza caixa
    caixa = Caixa()
    caixa.descricao= 'comanda'
    caixa.data = timezone.now()
    tipo_mov = TipoMovimento.objects.get(pk=2)
    caixa.tipo=  tipo_mov
    caixa.valor= pgto
    forma_pgto = FormaPgto.objects.get(pk=fpgto)
    caixa.forma_pgto_caixa= forma_pgto
    caixa.usuario =request.user.userprofile
    caixa.save()

    return redirect('lista_mesa')


def lista_pedidos_pdf(request, mesa_id):
    try:
        # Obtém a comanda associada à mesa
        comanda = Comanda.objects.get(mesa_id=mesa_id, staus_comanda='a')

        # Obtém os itens da comanda associada à mesa
        itens_comanda = ItemComanda.objects.filter(comanda=comanda)

        # Inicializa variáveis para o valor total e lista de itens com detalhes
        valor_total_comanda = 0
        itens_detalhados = []

        # Calcula o total por item e o valor total da comanda
        for item in itens_comanda:
            descricao_item_menu = item.item_menu.item_menu
            preco_item_menu = item.item_menu.preco
            quantidade_item_comanda = item.quantidade
            total_por_item = preco_item_menu * quantidade_item_comanda

            # Adiciona detalhes do item ao total
            itens_detalhados.append({
                'descricao': descricao_item_menu,
                'preco_unitario': preco_item_menu,
                'quantidade': quantidade_item_comanda,
                'total_por_item': total_por_item,
            })

            # Atualiza o valor total da comanda
            valor_total_comanda += total_por_item
        itens_detalhados.append({'total_comanda': valor_total_comanda})
        colunas = 40
        imprimir_lista(str(itens_detalhados).format(*['{:<20}'.format(key) for key in itens_detalhados[0].keys()]),
                       "lpt")
        return render(request, 'Menu\lista_pedido.html',
                      {'itens_detalhados': itens_detalhados,
                       'valor_total_comanda': valor_total_comanda, 'Mesa': mesa_id})

    except Comanda.DoesNotExist:
        return render(request, 'Menu\lista_pedido.html',
                      {'mensagem': 'Não existe comanda para esta Mesa', 'Mesa': mesa_id})


################################################################################


def imprimir_itens_detalhados(request, mesa_id):
    try:
        # Obtém a comanda associada à mesa
        comanda = Comanda.objects.get(pk=mesa_id, staus_comanda='a')

        # Obtém os itens da comanda associada à mesa
        itens_comanda = ItemComanda.objects.filter(comanda=comanda)

        # Inicializa variáveis para o valor total e lista de itens com detalhes
        valor_total_comanda = 0
        itens_detalhados = []

        # Calcula o total por item e o valor total da comanda
        for item in itens_comanda:
            descricao_item_menu = item.item_menu.item_menu
            preco_item_menu = item.item_menu.preco
            quantidade_item_comanda = item.quantidade
            total_por_item = preco_item_menu * quantidade_item_comanda

            # Adiciona detalhes do item ao total
            itens_detalhados.append({
                'descricao': descricao_item_menu,
                'preco_unitario': preco_item_menu,
                'quantidade': quantidade_item_comanda,
                'total_por_item': total_por_item,
            })

            # Atualiza o valor total da comanda
            valor_total_comanda += total_por_item
        itens_detalhados.append({'total_comanda': valor_total_comanda})
        itens_detalhados.append({'mesa': mesa_id})

        # Converte a lista de itens detalhados em uma string
        itens_detalhados_str = " ".join([str(item) for item in itens_detalhados])
        #
        #      "response = HttpResponse(content_type='application/pdf')
        #     response['Content-Disposition'] = 'attachment; filename="itens_detalhados.pdf"'
        #     response.write(itens_detalhados_str.encode())  # Escrevi diretamente na resposta
        #     return response

        context = {'itens': itens_detalhados, 'mesa': mesa_id}

        return render(request, 'Menu/imprimir_comanda.html', context)


    except Comanda.DoesNotExist:
        return render(request, 'Menu\lista_pedido.html',
                      {'mensagem': 'Não existe comanda para esta Mesa', 'Mesa': mesa_id})


def imprimir_lista(lista):
    colunas = 40
    os.system("lpr -l -P lpt1 {}".format(" ".join([str(item) for item in lista])))


#################### Mesas
@login_required()
def cadastra_mesa(request):
    if request.method == 'POST':
        form = MesasForm(request.POST)
        if form.is_valid():
            # salva os dados no bd

            mesa = form.save()
            mesa.status_mesa = 'o'
            ultima_mesa  = mesa.pk
            mesa_id= ultima_mesa
            hora_atual = datetime.now()
            hora_fim= "00:00:00"
            comanda, created = Comanda.objects.get_or_create(
                mesa_id=mesa_id,
                staus_comanda='a',
                defaults={'data_cad': date.today(), 'hora_inicio': datetime.now().time()}
            )
            # Associe o usuário ao menu
            usuario_perfil = request.user.userprofile
            #    mesa.usuario = usuario_perfil

            # Salve o menu no banco de dados
            mesa.save()

            # Adicione a mensagem de sucesso
            messages.success(request, 'Operação realizada com sucesso!')
            return redirect('cadastra_mesa')
        # Redirecione para a mesma página
        else:
            return redirect('Menu/cadastra_mesa.html')
    else:
        form = MesasForm()
        return render(request, 'Menu/cadastra_mesa.html', {'form': form})


def lista_mesa(request):
    lista_mesas = Mesas.objects.filter

    context = {'mesas': lista_mesas}
    return (render(request, 'Menu/lista_mesa.html', context))


def mesa_edit(request, id):
    mesa = get_object_or_404(Mesas, id=id)

    if request.method == 'POST':
        form = MesasForm(request.POST, instance=mesa)
        if form.is_valid():
            mesa = form.save()
            return redirect('mesa_edit', id=mesa.id)  # Correção aqui
    else:
        form = MesasForm(instance=mesa)

    return render(request, 'Menu/mesa_edit.html', {'form': form})


def mesa_delete(request, id):
    mesa = get_object_or_404(Mesas, id=id)

    if request.method == 'POST':
        form = MesasDeleteForm(request.POST)
        if form.is_valid() and form.cleaned_data['confirm_delete']:
            mesa.delete()
            messages.success(request, 'Operação realizada com sucesso!')
            return redirect('lista_mesa')  # Substitua 'alguma_view' pela view apropriada após a exclusão
    else:
        form = MesasDeleteForm()
    return render(request, 'Menu\mesa_delete.html', {'form': form, 'mesa': mesa})


def mesa_mudar(request, id):
    mesa = get_object_or_404(Mesas, id=id)
    if request.method == 'POST':
        form = MesasForm(request.POST, instance=mesa)
        if form.is_valid():
            mesa = form.save()
            return redirect('mesa_mudar', id=mesa.id)  # Correção aqui
    else:
        form = MesasForm(instance=mesa)

    return render(request, 'Menu/mesa_mudar.html', {'form': form, 'mesa': mesa})


def lista_cardapio(request, id):
    usuario_perfil = request.user.userprofile

    mesa = Mesas.objects.get(id=id)
    mesa_id = mesa.id
    comanda = Comanda.objects.get_or_create(mesa=mesa, staus_comanda='a')
    # comanda_id = comanda.pk
    query = request.GET.get('q', '')

    menus = Menu.objects.filter(
        Q(descricao__icontains=query) | Q(grupomen__descricao__icontains=query)).order_by('grupomen__descricao',
                                                                                          'item_menu')

    return render(request, 'Menu\lista_cardapio.html ', {'menus': menus, 'mesa': mesa_id})


def atualiza_itens_pedido(request, mesa_id):
    if request.method == 'POST':
        selected_items = request.POST.getlist('selected_items')
        mesa_id = request.POST.get('mesa_id')

        for item_id in selected_items:
            menu = Menu.objects.get(id=item_id)
            quantidade = int(request.POST.get(f'quantidade_{item_id}', 1))

            item_comanda, created = ItemComanda.objects.get_or_create(comanda_mesa_id=mesa_id, item_menu=menu)

            item_comanda.quantidade += quantidade if not created else quantidade
            item_comanda.save()

    # Corrigindo a passagem do valor de mesa_id no redirecionamento
    return redirect('Menu/lista_pedido', mesa_id=mesa_id)


###########################################


def novo_item(request, menu_id, mesa_id):
    if request.method != 'POST':
        return HttpResponse("Invalid request method")

    quantidade_str = request.POST.get('quantidade_hidden')  # Defina um valor padrão se necessário
    if quantidade_str:
        try:
           quantidade = int(quantidade_str)  # Converta para um inteiro, se necessário
        except ValueError:
        # Lida com o caso em que a string não pode ser convertida para um inteiro

             quantidade = 1  # Defina um valor padrão
    else:
     quantidade = 1  # Se quantidade_str estiver vazio, defina um valor padrão
     messages.error(request, f"Erro quantidade vazia: quantidade ")
 #    return redirect('mapa_mesas')

    # Verificar se a mesa existe
    mesa = get_object_or_404(Mesas, pk=mesa_id)

    # Verificar se a comanda já existe
    comanda, created = Comanda.objects.get_or_create(
        mesa_id=mesa,
        staus_comanda='a',
        defaults={'data_cad': date.today(), 'hora_inicio': datetime.now().time()}
    )
    messages.success(request, "criando comanda.")
    # Se a comanda não existir, criamos uma nova e associamos à mesa
    if created:
        comanda.mesa_id = mesa
        comanda.save()

    # Atualiza o status da mesa apenas se a comanda foi criada
    if created:
        mesa.status_mesa = 'o'
        mesa.save()

    # Adiciona o item ao ItemComanda
    menu = get_object_or_404(Menu, pk=menu_id)

    try:

        item_comanda  = ItemComanda.objects.create(
            comanda=comanda,
            item_menu=menu,
            quantidade= quantidade, status= 'a'
        )
        item_comanda.save()
        messages.success(request, "Item comanda criada com sucesso.")

    except Exception as e:
        messages.error(request, f"Erro ao inserir item na comanda: quantidade {e}")
        return redirect('lista_pedido', mesa_id=mesa_id )

    # Mensagens de feedback
    if created:
        messages.success(request, "Comanda criada com sucesso.")
    messages.success(request, "Item adicionado à comanda.")

    return redirect('lista_pedido', mesa_id=mesa_id)


def lista_comandas(request):
    lista_comandas = Comanda.objects.filter(staus_comanda='a')

    # Convertendo os campos de data para strings
    comandas_formatadas = []
    for comanda in lista_comandas:
    #    data_cad_str = comanda.data_cad.strftime("%Y-%m-%d")
    #    hora_inicio_str = comanda.hora_inicio.strftime("%H:%M:%S")
     #   hora_fim_str = comanda.hora_fim.strftime("%H:%M:%S")

        comanda_formatada = {
            'id': comanda.id,
            'descricao': comanda.descricao,
            'mesa': comanda.mesa,
            'usuario': comanda.usuario,
            'staus_comanda': comanda.staus_comanda

        }

        comandas_formatadas.append(comanda_formatada)

    context = {'comandas_abertas': comandas_formatadas}
    return render(request, 'Menu/lista_comandas.html', context)

@login_required()
def cadastra_comandas(request):
    if request.method == 'POST':
        form = ComandasForm(request.POST)
        if form.is_valid():
            # salva os dados no bd
            Comanda.staus_comanda='a'
            Comanda.data_cad = str(date.today())
            Comanda.hora_inicio= str(datetime.now())
            Comanda.hora_fim = "00:00:00"
            comanda = form.save(commit=False)

            # Associe o usuário ao menu
            usuario_perfil = request.user.userprofile
            #    mesa.usuario = usuario_perfil

            # Salve o menu no banco de dados
            comanda.save()

            # Adicione a mensagem de sucesso
            messages.success(request, 'Operação realizada com sucesso!')
            return redirect('cadastra_comandas')
        # Redirecione para a mesma página
        else:
            return redirect('Menu/cadastra_mesa.html')
    else:
        form = ComandasForm()
        return render(request, 'Menu/cadastra_comandas.html', {'form': form})


class MesasAbertasListView(ListView):
    model = Mesas
    template_name = 'Menu/mesas_abertas_list.html'
    context_object_name = 'mesas_abertas'

    def get_queryset(self):
        """Filtra os resultados para mostrar apenas mesas abertas."""
        return super().get_queryset().filter(status_mesa='o')

    ############# PDV

def pdv_view(request):
    if request.method == 'POST':
        form = PDVForm(request.POST)
        if form.is_valid():
            comanda = form.cleaned_data['comanda_selecionada']
            forma_pagamento = form.cleaned_data['forma_pagamento']
            valor_pago = form.cleaned_data['valor_pago']

            # Lógica para calcular o valor total dos itens em ItemComanda
            itens_comanda = comanda.itemcomanda_set.all()
            valor_total = sum(item.item_menu.preco * item.quantidade for item in itens_comanda)

            # Lógica para calcular o troco, se a forma de pagamento for dinheiro
            troco = 0.0
            if forma_pagamento.nome == 'Dinheiro':
                troco = valor_pago - valor_total

            # Lógica para imprimir o recibo, atualizar o caixa, etc.

            # Exemplo de atualização do caixa
            Caixa.objects.create(valor=valor_total, tipo=TipoMovimento.objects.get(nome='Entrada'), descricao='Venda', forma_pgto_caixa=forma_pagamento, data=timezone.now(), usuario=request.user)

            return render(request, 'Menu/pdv_template.html', {'form': form, 'itens_comanda': itens_comanda, 'valor_total': valor_total})

    else:
        form = PDVForm()

    return render(request, 'Menu/pdv_template.html', {'form': form})

def detalhes_comanda_view(request, comanda_id):
    comanda = get_object_or_404(Comanda, id=comanda_id)
    itens_comanda = comanda.itemcomanda_set.all()

    valor_total = sum(item.item_menu.preco * item.quantidade for item in itens_comanda)

    return render(request, 'Menu/'
                           'detalhes_comanda_template.html', {'comanda': comanda, 'itens_comanda': itens_comanda, 'valor_total': valor_total})



def Fechar_Pedidos(request, mesa_id):
    try:
        print('estou aqui')
        # Obtém a comanda associada à mesa
        comanda = Comanda.objects.get(mesa_id=mesa_id, staus_comanda='a')
        comanda_num= comanda.id

        # Obtém os itens da comanda associada à mesa, incluindo informações do item_menu
        itens_comanda = ItemComanda.objects.filter(comanda=comanda)

        # Inicializa variáveis para o valor total e lista de itens com detalhes
        valor_total_comanda = 0
        itens_detalhados = []

        # Calcula o total por item e o valor total da comanda
        for item in itens_comanda:

            descricao_item_menu = item.item_menu.item_menu
            preco_item_menu = item.item_menu.preco
            quantidade_item_comanda = item.quantidade
            total_por_item = preco_item_menu * quantidade_item_comanda

            # Adiciona detalhes do item ao total
            itens_detalhados.append({
                'descricao': descricao_item_menu,
                'preco_unitario': preco_item_menu,
                'quantidade': quantidade_item_comanda,
                'total_por_item': total_por_item,
            })

            # Atualiza o valor total da comanda
            valor_total_comanda += total_por_item
           # forma de pagamento
            pgto = FormaPgto.objects.all()

        return render(request, 'Menu/fechar_comandas.html',
                      {'itens_detalhados': itens_detalhados,
                       'valor_total_comanda': valor_total_comanda, 'Mesa': mesa_id, 'comanda_num':comanda_num, 'formapgto':pgto})

    except Comanda.DoesNotExist:
        return render(request, 'Menu/fechar_comandas.html',
                      {'mensagem': 'Não existe comanda para esta Mesa', 'Mesa': mesa_id})

def Finaliza_Comanda(request, pk, pgto, fpgto):
        mesa = Mesas.objects.get(id=pk)
        mesa.status_mesa = 'l'
        mesa.save()
        # atualiza comandas
        comanda = Comanda.objects.get(mesa=mesa, staus_comanda='a')
        comanda.staus_comanda = 'f'
        comanda.hora_fim = timezone.now()

        comanda.save()
        # atualuza caixa
        caixa = Caixa()
        caixa.descricao = 'comanda'
        caixa.data = timezone.now()
        tipo_mov = TipoMovimento.objects.get(pk=2)
        caixa.tipo = tipo_mov
        caixa.valor = pgto
        forma_pgto = FormaPgto.objects.get(pk=fpgto)
        caixa.forma_pgto_caixa = forma_pgto
        caixa.usuario = request.user.userprofile
        caixa.save()

        return redirect('lista_mesa')
