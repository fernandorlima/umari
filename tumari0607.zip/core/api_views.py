from rest_framework import generics
from rest_framework import serializers
from core.models import Comanda, ItemComanda, Mesas, GrupoMenu, Menu, User, UserProfile
from core.serializers import GrupoMenuserializer, Menuserializers, Comandaserializer, Mesasserializers,\
    Itemcomandaserializer,  Userserializer, userprofileserializer
#autenticação e permissoes
from rest_framework.authentication import SessionAuthentication
from rest_framework.permissions import  IsAuthenticated, IsAdminUser

from rest_framework import viewsets

class GrupoMenuViewSet(viewsets.ModelViewSet):
    queryset = GrupoMenu.objects.all()
    serializer_class = GrupoMenuserializer
    authentication_classes = [SessionAuthentication]
    permission_classes = (IsAuthenticated,)


class MenuViewSet(viewsets.ModelViewSet):
    queryset = Menu.objects.all()
    serializer_class =Menuserializers
    authentication_classes = [SessionAuthentication]
    permission_classes = (IsAuthenticated,)


class CoamandaViewSet(viewsets.ModelViewSet):

        queryset = Comanda.objects.all()
        serializer_class = Comandaserializer
        authentication_classes = [SessionAuthentication]
        permission_classes = (IsAuthenticated,)


class MessasViewSet(viewsets.ModelViewSet):
    queryset = Mesas.objects.all()
    serializer_class = Mesasserializers
    authentication_classes = [SessionAuthentication]
    permission_classes = (IsAuthenticated,)


class ItemcomandaVewSet(viewsets.ModelViewSet):
    queryset= ItemComanda.objects.all()
    serializer_class = Itemcomandaserializer
    authentication_classes = [SessionAuthentication]
    permission_classes = (IsAuthenticated,)


class userViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class =Userserializer
    authentication_classes = [SessionAuthentication]
    permission_classes = (IsAuthenticated,)


class UserprofileViewSet(viewsets.ModelViewSet):
    queryset =UserProfile.objects.all()
    serialiser_class = userprofileserializer
    authentication_classes = [SessionAuthentication]
    permission_classes = (IsAuthenticated,)
