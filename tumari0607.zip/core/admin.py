from django.contrib import admin
from .models import(Menu, Clientes,Produto, Mesas, Saidas, Comanda, Entradas, Fornecedor, Unidades, ItemComanda, GrupoMenu ,
                    FormaPgto, TipoMovimento, Conta, Pagamento, Caixa, ContasPagar, UserProfile, Grupos)
# Register your models here.

admin.site.register(Menu)
admin.site.register(Produto)
admin.site.register(Mesas)
admin.site.register(Comanda)
admin.site.register(Entradas)
admin.site.register(Saidas)
admin.site.register(Fornecedor)
admin.site.register(Unidades)
admin.site.register(ItemComanda)
admin.site.register(GrupoMenu)
admin.site.register(FormaPgto)
admin.site.register(TipoMovimento)
admin.site.register(Conta)
admin.site.register(Pagamento)
admin.site.register(Caixa)
admin.site.register(ContasPagar)
admin.site.register(UserProfile)
admin.site.register(Grupos)