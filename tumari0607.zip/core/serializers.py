from rest_framework import serializers
from .models import Comanda, ItemComanda, Mesas, GrupoMenu, Menu, User, UserProfile

class GrupoMenuserializer(serializers.ModelSerializer):
    class Meta:
          model=GrupoMenu
          fields = '__all__'

class Menuserializers(serializers.ModelSerializer):
    class Meta:
        model = Menu
        fields= '__all__'

class Comandaserializer(serializers.ModelSerializer):
    class Meta:
       model=Comanda
       fields='__all__'

class Itemcomandaserializer(serializers.ModelSerializer):
    class Meta:
         model=ItemComanda
         fields='__all__'

class Mesasserializers(serializers.ModelSerializer):
    class Meta:
      model=Mesas
      fields='__all__'

class Userserializer(serializers.ModelSerializer):
    class Meta:
        model=User
        fields='__all__'

class userprofileserializer(serializers.ModelSerializer):
    class Meta:
         model=UserProfile
         fields='__all_'

