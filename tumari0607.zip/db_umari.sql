--
-- File generated with SQLiteStudio v3.4.4 on dom mar 3 22:51:43 2024
--
-- Text encoding used: UTF-8
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Table: auth_group
CREATE TABLE auth_group (
    id   INTEGER       NOT NULL
                       PRIMARY KEY AUTOINCREMENT,
    name VARCHAR (150) NOT NULL
                       UNIQUE
);

INSERT INTO auth_group (
                           id,
                           name
                       )
                       VALUES (
                           1,
                           'gerencia'
                       );

INSERT INTO auth_group (
                           id,
                           name
                       )
                       VALUES (
                           2,
                           'garcon'
                       );


-- Table: auth_group_permissions
CREATE TABLE auth_group_permissions (
    id            INTEGER NOT NULL
                          PRIMARY KEY AUTOINCREMENT,
    group_id      INTEGER NOT NULL
                          REFERENCES auth_group (id) DEFERRABLE INITIALLY DEFERRED,
    permission_id INTEGER NOT NULL
                          REFERENCES auth_permission (id) DEFERRABLE INITIALLY DEFERRED
);

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       1,
                                       1,
                                       1
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       2,
                                       1,
                                       2
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       3,
                                       1,
                                       3
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       4,
                                       1,
                                       4
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       5,
                                       1,
                                       5
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       6,
                                       1,
                                       6
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       7,
                                       1,
                                       7
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       8,
                                       1,
                                       8
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       9,
                                       1,
                                       9
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       10,
                                       1,
                                       10
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       11,
                                       1,
                                       11
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       12,
                                       1,
                                       12
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       13,
                                       1,
                                       13
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       14,
                                       1,
                                       14
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       15,
                                       1,
                                       15
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       16,
                                       1,
                                       16
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       17,
                                       1,
                                       17
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       18,
                                       1,
                                       18
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       19,
                                       1,
                                       19
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       20,
                                       1,
                                       20
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       21,
                                       1,
                                       21
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       22,
                                       1,
                                       22
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       23,
                                       1,
                                       23
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       24,
                                       1,
                                       24
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       25,
                                       1,
                                       25
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       26,
                                       1,
                                       26
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       27,
                                       1,
                                       27
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       28,
                                       1,
                                       28
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       29,
                                       1,
                                       29
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       30,
                                       1,
                                       30
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       31,
                                       1,
                                       31
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       32,
                                       1,
                                       32
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       33,
                                       1,
                                       33
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       34,
                                       1,
                                       34
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       35,
                                       1,
                                       35
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       36,
                                       1,
                                       36
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       37,
                                       1,
                                       37
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       38,
                                       1,
                                       38
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       39,
                                       1,
                                       39
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       40,
                                       1,
                                       40
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       41,
                                       1,
                                       41
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       42,
                                       1,
                                       42
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       43,
                                       1,
                                       43
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       44,
                                       1,
                                       44
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       45,
                                       1,
                                       45
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       46,
                                       1,
                                       46
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       47,
                                       1,
                                       47
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       48,
                                       1,
                                       48
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       49,
                                       1,
                                       49
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       50,
                                       1,
                                       50
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       51,
                                       1,
                                       51
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       52,
                                       1,
                                       52
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       53,
                                       1,
                                       53
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       54,
                                       1,
                                       54
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       55,
                                       1,
                                       55
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       56,
                                       1,
                                       56
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       57,
                                       1,
                                       57
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       58,
                                       1,
                                       58
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       59,
                                       1,
                                       59
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       60,
                                       1,
                                       60
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       61,
                                       1,
                                       61
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       62,
                                       1,
                                       62
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       63,
                                       1,
                                       63
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       64,
                                       1,
                                       64
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       65,
                                       1,
                                       65
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       66,
                                       1,
                                       66
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       67,
                                       1,
                                       67
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       68,
                                       1,
                                       68
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       69,
                                       1,
                                       69
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       70,
                                       1,
                                       70
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       71,
                                       1,
                                       71
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       72,
                                       1,
                                       72
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       73,
                                       1,
                                       73
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       74,
                                       1,
                                       74
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       75,
                                       1,
                                       75
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       76,
                                       1,
                                       76
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       77,
                                       2,
                                       70
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       78,
                                       2,
                                       72
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       79,
                                       2,
                                       49
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       80,
                                       2,
                                       50
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       81,
                                       2,
                                       51
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       82,
                                       2,
                                       52
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       83,
                                       2,
                                       53
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       84,
                                       2,
                                       54
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       85,
                                       2,
                                       55
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       86,
                                       2,
                                       56
                                   );

INSERT INTO auth_group_permissions (
                                       id,
                                       group_id,
                                       permission_id
                                   )
                                   VALUES (
                                       87,
                                       2,
                                       60
                                   );


-- Table: auth_permission
CREATE TABLE auth_permission (
    id              INTEGER       NOT NULL
                                  PRIMARY KEY AUTOINCREMENT,
    content_type_id INTEGER       NOT NULL
                                  REFERENCES django_content_type (id) DEFERRABLE INITIALLY DEFERRED,
    codename        VARCHAR (100) NOT NULL,
    name            VARCHAR (255) NOT NULL
);

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                1,
                                1,
                                'add_logentry',
                                'Can add log entry'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                2,
                                1,
                                'change_logentry',
                                'Can change log entry'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                3,
                                1,
                                'delete_logentry',
                                'Can delete log entry'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                4,
                                1,
                                'view_logentry',
                                'Can view log entry'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                5,
                                2,
                                'add_permission',
                                'Can add permission'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                6,
                                2,
                                'change_permission',
                                'Can change permission'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                7,
                                2,
                                'delete_permission',
                                'Can delete permission'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                8,
                                2,
                                'view_permission',
                                'Can view permission'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                9,
                                3,
                                'add_group',
                                'Can add group'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                10,
                                3,
                                'change_group',
                                'Can change group'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                11,
                                3,
                                'delete_group',
                                'Can delete group'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                12,
                                3,
                                'view_group',
                                'Can view group'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                13,
                                4,
                                'add_user',
                                'Can add user'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                14,
                                4,
                                'change_user',
                                'Can change user'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                15,
                                4,
                                'delete_user',
                                'Can delete user'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                16,
                                4,
                                'view_user',
                                'Can view user'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                17,
                                5,
                                'add_contenttype',
                                'Can add content type'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                18,
                                5,
                                'change_contenttype',
                                'Can change content type'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                19,
                                5,
                                'delete_contenttype',
                                'Can delete content type'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                20,
                                5,
                                'view_contenttype',
                                'Can view content type'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                21,
                                6,
                                'add_session',
                                'Can add session'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                22,
                                6,
                                'change_session',
                                'Can change session'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                23,
                                6,
                                'delete_session',
                                'Can delete session'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                24,
                                6,
                                'view_session',
                                'Can view session'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                25,
                                7,
                                'add_clientes',
                                'Can add clientes'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                26,
                                7,
                                'change_clientes',
                                'Can change clientes'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                27,
                                7,
                                'delete_clientes',
                                'Can delete clientes'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                28,
                                7,
                                'view_clientes',
                                'Can view clientes'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                29,
                                8,
                                'add_unidades',
                                'Can add unidades'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                30,
                                8,
                                'change_unidades',
                                'Can change unidades'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                31,
                                8,
                                'delete_unidades',
                                'Can delete unidades'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                32,
                                8,
                                'view_unidades',
                                'Can view unidades'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                33,
                                9,
                                'add_grupos',
                                'Can add grupos'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                34,
                                9,
                                'change_grupos',
                                'Can change grupos'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                35,
                                9,
                                'delete_grupos',
                                'Can delete grupos'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                36,
                                9,
                                'view_grupos',
                                'Can view grupos'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                37,
                                10,
                                'add_entradas',
                                'Can add entradas'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                38,
                                10,
                                'change_entradas',
                                'Can change entradas'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                39,
                                10,
                                'delete_entradas',
                                'Can delete entradas'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                40,
                                10,
                                'view_entradas',
                                'Can view entradas'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                41,
                                11,
                                'add_fornecedor',
                                'Can add fornecedor'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                42,
                                11,
                                'change_fornecedor',
                                'Can change fornecedor'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                43,
                                11,
                                'delete_fornecedor',
                                'Can delete fornecedor'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                44,
                                11,
                                'view_fornecedor',
                                'Can view fornecedor'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                45,
                                12,
                                'add_saidas',
                                'Can add saidas'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                46,
                                12,
                                'change_saidas',
                                'Can change saidas'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                47,
                                12,
                                'delete_saidas',
                                'Can delete saidas'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                48,
                                12,
                                'view_saidas',
                                'Can view saidas'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                49,
                                13,
                                'add_itemcomanda',
                                'Can add item comanda'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                50,
                                13,
                                'change_itemcomanda',
                                'Can change item comanda'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                51,
                                13,
                                'delete_itemcomanda',
                                'Can delete item comanda'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                52,
                                13,
                                'view_itemcomanda',
                                'Can view item comanda'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                53,
                                14,
                                'add_comanda',
                                'Can add comanda'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                54,
                                14,
                                'change_comanda',
                                'Can change comanda'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                55,
                                14,
                                'delete_comanda',
                                'Can delete comanda'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                56,
                                14,
                                'view_comanda',
                                'Can view comanda'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                57,
                                15,
                                'add_menu',
                                'Can add menu'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                58,
                                15,
                                'change_menu',
                                'Can change menu'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                59,
                                15,
                                'delete_menu',
                                'Can delete menu'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                60,
                                15,
                                'view_menu',
                                'Can view menu'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                61,
                                16,
                                'add_userprofile',
                                'Can add user profile'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                62,
                                16,
                                'change_userprofile',
                                'Can change user profile'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                63,
                                16,
                                'delete_userprofile',
                                'Can delete user profile'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                64,
                                16,
                                'view_userprofile',
                                'Can view user profile'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                65,
                                17,
                                'add_produto',
                                'Can add produto'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                66,
                                17,
                                'change_produto',
                                'Can change produto'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                67,
                                17,
                                'delete_produto',
                                'Can delete produto'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                68,
                                17,
                                'view_produto',
                                'Can view produto'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                69,
                                18,
                                'add_mesas',
                                'Can add mesas'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                70,
                                18,
                                'change_mesas',
                                'Can change mesas'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                71,
                                18,
                                'delete_mesas',
                                'Can delete mesas'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                72,
                                18,
                                'view_mesas',
                                'Can view mesas'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                73,
                                19,
                                'add_grupomenu',
                                'Can add grupo menu'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                74,
                                19,
                                'change_grupomenu',
                                'Can change grupo menu'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                75,
                                19,
                                'delete_grupomenu',
                                'Can delete grupo menu'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                76,
                                19,
                                'view_grupomenu',
                                'Can view grupo menu'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                77,
                                20,
                                'add_tipomovimentacao',
                                'Can add tipo movimentacao'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                78,
                                20,
                                'change_tipomovimentacao',
                                'Can change tipo movimentacao'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                79,
                                20,
                                'delete_tipomovimentacao',
                                'Can delete tipo movimentacao'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                80,
                                20,
                                'view_tipomovimentacao',
                                'Can view tipo movimentacao'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                81,
                                21,
                                'add_movimentacao',
                                'Can add movimentacao'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                82,
                                21,
                                'change_movimentacao',
                                'Can change movimentacao'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                83,
                                21,
                                'delete_movimentacao',
                                'Can delete movimentacao'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                84,
                                21,
                                'view_movimentacao',
                                'Can view movimentacao'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                85,
                                22,
                                'add_conta',
                                'Can add conta'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                86,
                                22,
                                'change_conta',
                                'Can change conta'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                87,
                                22,
                                'delete_conta',
                                'Can delete conta'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                88,
                                22,
                                'view_conta',
                                'Can view conta'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                89,
                                23,
                                'add_contaspagar',
                                'Can add contas pagar'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                90,
                                23,
                                'change_contaspagar',
                                'Can change contas pagar'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                91,
                                23,
                                'delete_contaspagar',
                                'Can delete contas pagar'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                92,
                                23,
                                'view_contaspagar',
                                'Can view contas pagar'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                93,
                                24,
                                'add_formapgto',
                                'Can add forma pgto'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                94,
                                24,
                                'change_formapgto',
                                'Can change forma pgto'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                95,
                                24,
                                'delete_formapgto',
                                'Can delete forma pgto'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                96,
                                24,
                                'view_formapgto',
                                'Can view forma pgto'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                97,
                                25,
                                'add_pagamento',
                                'Can add pagamento'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                98,
                                25,
                                'change_pagamento',
                                'Can change pagamento'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                99,
                                25,
                                'delete_pagamento',
                                'Can delete pagamento'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                100,
                                25,
                                'view_pagamento',
                                'Can view pagamento'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                101,
                                26,
                                'add_caixa',
                                'Can add caixa'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                102,
                                26,
                                'change_caixa',
                                'Can change caixa'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                103,
                                26,
                                'delete_caixa',
                                'Can delete caixa'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                104,
                                26,
                                'view_caixa',
                                'Can view caixa'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                105,
                                27,
                                'add_tipomovimento',
                                'Can add tipo movimento'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                106,
                                27,
                                'change_tipomovimento',
                                'Can change tipo movimento'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                107,
                                27,
                                'delete_tipomovimento',
                                'Can delete tipo movimento'
                            );

INSERT INTO auth_permission (
                                id,
                                content_type_id,
                                codename,
                                name
                            )
                            VALUES (
                                108,
                                27,
                                'view_tipomovimento',
                                'Can view tipo movimento'
                            );


-- Table: auth_user
CREATE TABLE auth_user (
    id           INTEGER       NOT NULL
                               PRIMARY KEY AUTOINCREMENT,
    password     VARCHAR (128) NOT NULL,
    last_login   DATETIME,
    is_superuser BOOL          NOT NULL,
    username     VARCHAR (150) NOT NULL
                               UNIQUE,
    last_name    VARCHAR (150) NOT NULL,
    email        VARCHAR (254) NOT NULL,
    is_staff     BOOL          NOT NULL,
    is_active    BOOL          NOT NULL,
    date_joined  DATETIME      NOT NULL,
    first_name   VARCHAR (150) NOT NULL
);

INSERT INTO auth_user (
                          id,
                          password,
                          last_login,
                          is_superuser,
                          username,
                          last_name,
                          email,
                          is_staff,
                          is_active,
                          date_joined,
                          first_name
                      )
                      VALUES (
                          1,
                          'pbkdf2_sha256$600000$9XSX82YCTEkESdhiYrU0ni$a3/FufF/XjjwLP0+jmdZQoqVhLtafcw+ruc7DrMJN6Y=',
                          '2023-12-12 13:15:08.455443',
                          1,
                          'admin',
                          '',
                          'fernandorla20@gmail.com',
                          1,
                          1,
                          '2023-12-03 03:36:03.126035',
                          ''
                      );

INSERT INTO auth_user (
                          id,
                          password,
                          last_login,
                          is_superuser,
                          username,
                          last_name,
                          email,
                          is_staff,
                          is_active,
                          date_joined,
                          first_name
                      )
                      VALUES (
                          2,
                          'pbkdf2_sha256$600000$RLLdGg7UnO7LEonCx8ZVby$tHluMvI7xGJK0HZxzVVFqAHAl3YJ0tK/Nq2bpBt8xL8=',
                          '2024-02-21 00:21:02.194028',
                          0,
                          'gerente',
                          'Avila',
                          '',
                          0,
                          1,
                          '2023-12-13 13:28:31',
                          'Antonio'
                      );

INSERT INTO auth_user (
                          id,
                          password,
                          last_login,
                          is_superuser,
                          username,
                          last_name,
                          email,
                          is_staff,
                          is_active,
                          date_joined,
                          first_name
                      )
                      VALUES (
                          3,
                          'pbkdf2_sha256$600000$KxWLWMlEYmLmCaA9R1Eqhm$AYbtlh2+1bOD12uQ9Cns+8DD+zCM9pXYMf+ltl1UyC0=',
                          NULL,
                          0,
                          'garcon01',
                          '',
                          '',
                          0,
                          1,
                          '2023-12-13 13:31:51.796207',
                          ''
                      );

INSERT INTO auth_user (
                          id,
                          password,
                          last_login,
                          is_superuser,
                          username,
                          last_name,
                          email,
                          is_staff,
                          is_active,
                          date_joined,
                          first_name
                      )
                      VALUES (
                          4,
                          'pbkdf2_sha256$600000$CMgWbNKOXJI6xtoPlTCxuq$gvLdPHZ+Zb/qEe9m3USz3ZeBsH5eICRbN7P85OQebDg=',
                          NULL,
                          0,
                          'jose',
                          'silva',
                          'jose.silva@aaaa.com',
                          0,
                          1,
                          '2023-12-13 13:33:06',
                          'Jose'
                      );

INSERT INTO auth_user (
                          id,
                          password,
                          last_login,
                          is_superuser,
                          username,
                          last_name,
                          email,
                          is_staff,
                          is_active,
                          date_joined,
                          first_name
                      )
                      VALUES (
                          5,
                          'pbkdf2_sha256$600000$Zn76VQrPqHexpGsEAP0OcZ$+o3cIRwKUmM2R7GzQmCb1eAcPkO7By1imkbUCNQfMhQ=',
                          NULL,
                          0,
                          'pedro',
                          'Lima',
                          'pedro.lima@bbbb.com',
                          0,
                          1,
                          '2023-12-13 13:34:58',
                          'Pedro'
                      );

INSERT INTO auth_user (
                          id,
                          password,
                          last_login,
                          is_superuser,
                          username,
                          last_name,
                          email,
                          is_staff,
                          is_active,
                          date_joined,
                          first_name
                      )
                      VALUES (
                          6,
                          'pbkdf2_sha256$600000$cmArDKwuJdv4D4K4UW14un$4ihvS6aomkrD/lRCziqVZkSBm9UrIsivhH6UmvcLFmc=',
                          '2024-02-20 18:25:03.390533',
                          1,
                          'umarit',
                          '',
                          'fernandorla20@gmail.com',
                          1,
                          1,
                          '2024-02-20 18:22:40.503000',
                          ''
                      );


-- Table: auth_user_groups
CREATE TABLE auth_user_groups (
    id       INTEGER NOT NULL
                     PRIMARY KEY AUTOINCREMENT,
    user_id  INTEGER NOT NULL
                     REFERENCES auth_user (id) DEFERRABLE INITIALLY DEFERRED,
    group_id INTEGER NOT NULL
                     REFERENCES auth_group (id) DEFERRABLE INITIALLY DEFERRED
);

INSERT INTO auth_user_groups (
                                 id,
                                 user_id,
                                 group_id
                             )
                             VALUES (
                                 1,
                                 2,
                                 1
                             );

INSERT INTO auth_user_groups (
                                 id,
                                 user_id,
                                 group_id
                             )
                             VALUES (
                                 2,
                                 2,
                                 2
                             );

INSERT INTO auth_user_groups (
                                 id,
                                 user_id,
                                 group_id
                             )
                             VALUES (
                                 3,
                                 4,
                                 2
                             );

INSERT INTO auth_user_groups (
                                 id,
                                 user_id,
                                 group_id
                             )
                             VALUES (
                                 4,
                                 5,
                                 2
                             );


-- Table: auth_user_user_permissions
CREATE TABLE auth_user_user_permissions (
    id            INTEGER NOT NULL
                          PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL
                          REFERENCES auth_user (id) DEFERRABLE INITIALLY DEFERRED,
    permission_id INTEGER NOT NULL
                          REFERENCES auth_permission (id) DEFERRABLE INITIALLY DEFERRED
);


-- Table: core_caixa
CREATE TABLE core_caixa (
    id                  INTEGER       NOT NULL
                                      PRIMARY KEY AUTOINCREMENT,
    valor               DECIMAL       NOT NULL,
    descricao           VARCHAR (255) NOT NULL,
    data                DATETIME      NOT NULL,
    forma_pgto_caixa_id BIGINT        NOT NULL
                                      REFERENCES core_formapgto (id) DEFERRABLE INITIALLY DEFERRED,
    usuario_id          BIGINT
                                      REFERENCES core_userprofile (id) DEFERRABLE INITIALLY DEFERRED,
    tipo_id             BIGINT        NOT NULL
                                      REFERENCES core_tipomovimento (id) DEFERRABLE INITIALLY DEFERRED
);

INSERT INTO core_caixa (
                           id,
                           valor,
                           descricao,
                           data,
                           forma_pgto_caixa_id,
                           usuario_id,
                           tipo_id
                       )
                       VALUES (
                           1,
                           13,
                           'comanda',
                           '2024-02-21 00:57:39.111741',
                           1,
                           1,
                           2
                       );


-- Table: core_clientes
CREATE TABLE core_clientes (
    id         INTEGER       NOT NULL
                             PRIMARY KEY AUTOINCREMENT,
    nome       VARCHAR (80)  NOT NULL,
    endereco   VARCHAR (80)  NOT NULL,
    data_nasc  DATE          NOT NULL,
    email      VARCHAR (254) NOT NULL,
    data_cad   DATE          NOT NULL,
    usuario_id BIGINT
                             REFERENCES core_userprofile (id) DEFERRABLE INITIALLY DEFERRED
);


-- Table: core_comanda
CREATE TABLE core_comanda (
    id            INTEGER      NOT NULL
                               PRIMARY KEY AUTOINCREMENT,
    staus_comanda VARCHAR (1)  NOT NULL,
    data_cad      DATE         NOT NULL,
    hora_fim      VARCHAR (10) NOT NULL,
    mesa_id       BIGINT
                               REFERENCES core_mesas (id) DEFERRABLE INITIALLY DEFERRED,
    usuario_id    BIGINT
                               REFERENCES core_userprofile (id) DEFERRABLE INITIALLY DEFERRED,
    descricao     VARCHAR (50) NOT NULL,
    hora_inicio   VARCHAR (10) NOT NULL
);

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             14,
                             'a',
                             '2024-02-07',
                             'hora_fim',
                             1,
                             NULL,
                             'teste',
                             'hora_inicio'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             15,
                             'a',
                             '2024-02-07',
                             'hora_fim',
                             2,
                             NULL,
                             'teste',
                             'hora_inicio'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             16,
                             'f',
                             '2024-02-11',
                             'hora_fim',
                             3,
                             NULL,
                             'teste',
                             'hora_inicio'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             17,
                             'a',
                             '2024-02-07',
                             'hora_fim',
                             5,
                             NULL,
                             'teste',
                             'hora_inicio'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             18,
                             'a',
                             '2024-02-07',
                             'hora_fim',
                             4,
                             NULL,
                             'teste',
                             'hora_inicio'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             19,
                             'a',
                             '2024-02-08',
                             'hora_fim',
                             8,
                             NULL,
                             'teste',
                             'hora_inicio'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             20,
                             'a',
                             '2024-02-09',
                             'hora_fim',
                             12,
                             NULL,
                             'teste',
                             'hora_inicio'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             21,
                             'a',
                             '2024-02-13',
                             'hora_fim',
                             NULL,
                             NULL,
                             'teste',
                             'hora_inicio'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             22,
                             'a',
                             '2024-02-14',
                             'hora_fim',
                             NULL,
                             NULL,
                             'teste',
                             'hora_inicio'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             23,
                             'a',
                             '2024-02-17',
                             '00:00:00',
                             NULL,
                             NULL,
                             '',
                             '2024-02-17 22:46:47.983790'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             24,
                             'a',
                             '2024-02-19',
                             '',
                             46,
                             NULL,
                             '',
                             '11:13:31.927088'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             25,
                             'a',
                             '2024-02-19',
                             '',
                             47,
                             NULL,
                             '',
                             '11:23:21.164534'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             26,
                             'f',
                             '2024-02-19',
                             '2024-02-19 18:49:46.936926+00:00',
                             51,
                             NULL,
                             '',
                             '15:09:00.612513'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             27,
                             'f',
                             '2024-02-19',
                             '2024-02-19 20:12:22.783124+00:00',
                             52,
                             NULL,
                             '',
                             '17:04:50.563035'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             28,
                             'f',
                             '2024-02-19',
                             '2024-02-19 21:21:43.199301+00:00',
                             53,
                             NULL,
                             '',
                             '17:42:45.642860'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             29,
                             'f',
                             '2024-02-19',
                             '2024-02-19 21:29:13.747652+00:00',
                             54,
                             NULL,
                             '',
                             '18:28:07.747845'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             30,
                             'f',
                             '2024-02-19',
                             '2024-02-19 21:37:40.233678+00:00',
                             55,
                             NULL,
                             '',
                             '18:36:55.978361'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             31,
                             'f',
                             '2024-02-20',
                             '2024-02-20 12:35:37.516030+00:00',
                             56,
                             NULL,
                             '',
                             '09:34:36.484461'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             32,
                             'f',
                             '2024-02-20',
                             '2024-02-20 12:51:32.482890+00:00',
                             57,
                             NULL,
                             '',
                             '09:50:11.770996'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             33,
                             'f',
                             '2024-02-20',
                             '2024-02-21 00:22:35.976624+00:00',
                             58,
                             NULL,
                             '',
                             '21:21:22.049158'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             34,
                             'f',
                             '2024-02-20',
                             '2024-02-21 00:25:53.093543+00:00',
                             59,
                             NULL,
                             '',
                             '21:25:04.122091'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             35,
                             'f',
                             '2024-02-20',
                             '2024-02-21 00:35:23.021044+00:00',
                             60,
                             NULL,
                             '',
                             '21:34:15.459161'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             36,
                             'f',
                             '2024-02-20',
                             '2024-02-21 00:38:30.657576+00:00',
                             61,
                             NULL,
                             '',
                             '21:37:49.678986'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             37,
                             'f',
                             '2024-02-20',
                             '2024-02-21 00:57:38.788674+00:00',
                             62,
                             NULL,
                             '',
                             '21:57:01.110852'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             38,
                             'a',
                             '2024-02-20',
                             '',
                             63,
                             NULL,
                             '',
                             '23:05:11.873635'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             39,
                             'a',
                             '2024-02-24',
                             '',
                             64,
                             NULL,
                             '',
                             '11:17:10.915643'
                         );

INSERT INTO core_comanda (
                             id,
                             staus_comanda,
                             data_cad,
                             hora_fim,
                             mesa_id,
                             usuario_id,
                             descricao,
                             hora_inicio
                         )
                         VALUES (
                             40,
                             'a',
                             '2024-02-24',
                             '',
                             65,
                             NULL,
                             '',
                             '11:18:37.708022'
                         );


-- Table: core_conta
CREATE TABLE core_conta (
    id         INTEGER      NOT NULL
                            PRIMARY KEY AUTOINCREMENT,
    valor      DECIMAL      NOT NULL,
    vencimento DATE         NOT NULL,
    status     VARCHAR (20) NOT NULL,
    titulo_id  INTEGER      NOT NULL
                            REFERENCES core_contaspagar (id) DEFERRABLE INITIALLY DEFERRED,
    usuario_id BIGINT
                            REFERENCES core_userprofile (id) DEFERRABLE INITIALLY DEFERRED
);


-- Table: core_contaspagar
CREATE TABLE core_contaspagar (
    id         INTEGER      NOT NULL
                            PRIMARY KEY AUTOINCREMENT,
    nome_conta VARCHAR (80) NOT NULL
);


-- Table: core_entradas
CREATE TABLE core_entradas (
    id            INTEGER NOT NULL
                          PRIMARY KEY AUTOINCREMENT,
    entrada       INTEGER NOT NULL,
    preco         DECIMAL NOT NULL,
    data_entrada  DATE,
    data_cad      DATE    NOT NULL,
    fornecedor_id BIGINT
                          REFERENCES core_fornecedor (id) DEFERRABLE INITIALLY DEFERRED,
    produto_id    BIGINT
                          REFERENCES core_produto (id) DEFERRABLE INITIALLY DEFERRED,
    usuario_id    BIGINT
                          REFERENCES core_userprofile (id) DEFERRABLE INITIALLY DEFERRED
);


-- Table: core_formapgto
CREATE TABLE core_formapgto (
    id        INTEGER      NOT NULL
                           PRIMARY KEY AUTOINCREMENT,
    nome      VARCHAR (80) NOT NULL,
    descriçao VARCHAR (80) NOT NULL
);

INSERT INTO core_formapgto (
                               id,
                               nome,
                               descriçao
                           )
                           VALUES (
                               1,
                               'Pix',
                               'pix'
                           );

INSERT INTO core_formapgto (
                               id,
                               nome,
                               descriçao
                           )
                           VALUES (
                               2,
                               'Credito',
                               'credito'
                           );

INSERT INTO core_formapgto (
                               id,
                               nome,
                               descriçao
                           )
                           VALUES (
                               3,
                               'Debito',
                               'Debito'
                           );

INSERT INTO core_formapgto (
                               id,
                               nome,
                               descriçao
                           )
                           VALUES (
                               4,
                               'Dinheiro',
                               'Dinheiro'
                           );


-- Table: core_fornecedor
CREATE TABLE core_fornecedor (
    id         INTEGER       NOT NULL
                             PRIMARY KEY AUTOINCREMENT,
    nome       VARCHAR (80)  NOT NULL,
    endereco   VARCHAR (80)  NOT NULL,
    email      VARCHAR (254) NOT NULL,
    fone       VARCHAR (12)  NOT NULL,
    whatsapp   VARCHAR (12)  NOT NULL,
    tipo       VARCHAR (1)   NOT NULL,
    cpfcnpj    VARCHAR (13)  NOT NULL,
    usuario_id BIGINT
                             REFERENCES core_userprofile (id) DEFERRABLE INITIALLY DEFERRED
);


-- Table: core_grupomenu
CREATE TABLE core_grupomenu (
    id        INTEGER NOT NULL
                      PRIMARY KEY AUTOINCREMENT,
    data_cad  DATE    NOT NULL,
    descricao TEXT    NOT NULL
);

INSERT INTO core_grupomenu (
                               id,
                               data_cad,
                               descricao
                           )
                           VALUES (
                               1,
                               '2023-12-12',
                               'Tira Gosto'
                           );

INSERT INTO core_grupomenu (
                               id,
                               data_cad,
                               descricao
                           )
                           VALUES (
                               2,
                               '2023-12-12',
                               'Refeições'
                           );

INSERT INTO core_grupomenu (
                               id,
                               data_cad,
                               descricao
                           )
                           VALUES (
                               3,
                               '2023-12-12',
                               'Petiscos'
                           );

INSERT INTO core_grupomenu (
                               id,
                               data_cad,
                               descricao
                           )
                           VALUES (
                               4,
                               '2023-12-12',
                               'Porção'
                           );

INSERT INTO core_grupomenu (
                               id,
                               data_cad,
                               descricao
                           )
                           VALUES (
                               5,
                               '2023-12-12',
                               'Café da Manhã'
                           );

INSERT INTO core_grupomenu (
                               id,
                               data_cad,
                               descricao
                           )
                           VALUES (
                               6,
                               '2023-12-12',
                               'Porções (250Gr)'
                           );

INSERT INTO core_grupomenu (
                               id,
                               data_cad,
                               descricao
                           )
                           VALUES (
                               7,
                               '2023-12-12',
                               'Saladas'
                           );

INSERT INTO core_grupomenu (
                               id,
                               data_cad,
                               descricao
                           )
                           VALUES (
                               8,
                               '2023-12-12',
                               'Sucos'
                           );

INSERT INTO core_grupomenu (
                               id,
                               data_cad,
                               descricao
                           )
                           VALUES (
                               9,
                               '2023-12-12',
                               'Sanduiches'
                           );

INSERT INTO core_grupomenu (
                               id,
                               data_cad,
                               descricao
                           )
                           VALUES (
                               10,
                               '2023-12-12',
                               'Refrigerantes'
                           );

INSERT INTO core_grupomenu (
                               id,
                               data_cad,
                               descricao
                           )
                           VALUES (
                               11,
                               '2023-12-12',
                               'Bebidas'
                           );


-- Table: core_grupos
CREATE TABLE core_grupos (
    id         INTEGER      NOT NULL
                            PRIMARY KEY AUTOINCREMENT,
    descricao  VARCHAR (80) NOT NULL,
    usuario_id BIGINT
                            REFERENCES core_userprofile (id) DEFERRABLE INITIALLY DEFERRED
);


-- Table: core_itemcomanda
CREATE TABLE core_itemcomanda (
    id           INTEGER     NOT NULL
                             PRIMARY KEY AUTOINCREMENT,
    quantidade   INTEGER     NOT NULL,
    comanda_id   BIGINT
                             REFERENCES core_comanda (id) DEFERRABLE INITIALLY DEFERRED,
    item_menu_id BIGINT
                             REFERENCES core_menu (id) DEFERRABLE INITIALLY DEFERRED,
    status       VARCHAR (1) NOT NULL
);

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 34,
                                 1,
                                 18,
                                 28,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 35,
                                 1,
                                 18,
                                 7,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 36,
                                 1,
                                 18,
                                 30,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 37,
                                 1,
                                 18,
                                 26,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 38,
                                 1,
                                 16,
                                 28,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 39,
                                 1,
                                 16,
                                 1,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 40,
                                 1,
                                 16,
                                 30,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 41,
                                 1,
                                 20,
                                 28,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 42,
                                 1,
                                 20,
                                 7,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 43,
                                 1,
                                 15,
                                 28,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 44,
                                 1,
                                 15,
                                 7,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 45,
                                 1,
                                 16,
                                 7,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 46,
                                 1,
                                 16,
                                 9,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 47,
                                 1,
                                 16,
                                 28,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 48,
                                 1,
                                 15,
                                 28,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 49,
                                 1,
                                 15,
                                 28,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 50,
                                 1,
                                 26,
                                 28,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 51,
                                 1,
                                 26,
                                 9,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 52,
                                 1,
                                 26,
                                 21,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 53,
                                 1,
                                 27,
                                 7,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 54,
                                 1,
                                 27,
                                 3,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 55,
                                 1,
                                 28,
                                 28,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 56,
                                 1,
                                 28,
                                 28,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 57,
                                 1,
                                 29,
                                 28,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 58,
                                 1,
                                 29,
                                 7,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 59,
                                 1,
                                 29,
                                 9,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 60,
                                 1,
                                 29,
                                 30,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 61,
                                 1,
                                 29,
                                 22,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 62,
                                 1,
                                 30,
                                 9,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 63,
                                 1,
                                 31,
                                 28,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 64,
                                 1,
                                 31,
                                 30,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 65,
                                 1,
                                 31,
                                 2,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 66,
                                 1,
                                 32,
                                 28,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 67,
                                 1,
                                 32,
                                 4,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 68,
                                 1,
                                 32,
                                 27,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 69,
                                 1,
                                 32,
                                 28,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 70,
                                 1,
                                 32,
                                 17,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 71,
                                 1,
                                 32,
                                 6,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 72,
                                 1,
                                 33,
                                 23,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 73,
                                 1,
                                 33,
                                 6,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 74,
                                 1,
                                 33,
                                 28,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 75,
                                 1,
                                 34,
                                 28,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 76,
                                 1,
                                 34,
                                 1,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 77,
                                 1,
                                 34,
                                 10,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 78,
                                 1,
                                 34,
                                 14,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 79,
                                 1,
                                 35,
                                 28,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 80,
                                 1,
                                 35,
                                 1,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 81,
                                 1,
                                 35,
                                 3,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 82,
                                 1,
                                 35,
                                 2,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 83,
                                 1,
                                 36,
                                 21,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 84,
                                 1,
                                 37,
                                 5,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 85,
                                 1,
                                 38,
                                 7,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 86,
                                 1,
                                 38,
                                 17,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 87,
                                 1,
                                 38,
                                 14,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 88,
                                 1,
                                 38,
                                 28,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 89,
                                 1,
                                 38,
                                 30,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 90,
                                 1,
                                 40,
                                 28,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 91,
                                 1,
                                 40,
                                 28,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 92,
                                 1,
                                 40,
                                 9,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 93,
                                 1,
                                 40,
                                 7,
                                 'a'
                             );

INSERT INTO core_itemcomanda (
                                 id,
                                 quantidade,
                                 comanda_id,
                                 item_menu_id,
                                 status
                             )
                             VALUES (
                                 94,
                                 1,
                                 40,
                                 10,
                                 'a'
                             );


-- Table: core_menu
CREATE TABLE core_menu (
    id          INTEGER      NOT NULL
                             PRIMARY KEY AUTOINCREMENT,
    item_menu   VARCHAR (80) NOT NULL,
    descricao   TEXT         NOT NULL,
    porcao      VARCHAR (20) NOT NULL,
    data_cad    DATE         NOT NULL,
    grupomen_id BIGINT
                             REFERENCES core_grupomenu (id) DEFERRABLE INITIALLY DEFERRED,
    usuario_id  BIGINT
                             REFERENCES core_userprofile (id) DEFERRABLE INITIALLY DEFERRED,
    preco       DECIMAL      NOT NULL
);

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          1,
                          'Arrumadinho',
                          'charque, cuscuz, cebola, coentro',
                          '01',
                          '2023-12-31',
                          2,
                          NULL,
                          15
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          2,
                          'camarão no Alho e Oleo',
                          'camarao',
                          '01',
                          '2023-12-12',
                          2,
                          NULL,
                          10
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          3,
                          'CARNE DE SOL(200Gr)',
                          'CARNE DE SOL',
                          '01',
                          '2023-12-12',
                          2,
                          NULL,
                          22
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          4,
                          'ESCONDIDINHO DE MACAXEIRA',
                          'MACAXEIRA, CARNE DE SOL',
                          '01',
                          '2023-12-12',
                          1,
                          NULL,
                          14
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          5,
                          'FILE  TRINCHADO COM FRITAS',
                          'FILE, BATATA FRITA',
                          '01',
                          '2023-12-12',
                          1,
                          NULL,
                          13
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          6,
                          'FRANGO A PASSARINHA',
                          'FRANGO EM PEDAÇOS',
                          '01',
                          '2023-12-12',
                          1,
                          NULL,
                          25
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          7,
                          'ISCA DE FRANGO',
                          'FRANGO',
                          '01',
                          '2023-12-12',
                          3,
                          NULL,
                          30
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          8,
                          'ISCA DE PEIXE',
                          'PEIXE',
                          '01',
                          '2023-12-12',
                          3,
                          NULL,
                          35
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          9,
                          'LINGUIÇA CALABRESA',
                          'LINGUIÇA CALABRESA EM RODELAS FRITAS',
                          '01',
                          '2023-12-12',
                          3,
                          NULL,
                          30
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          10,
                          'LINGUIÇA MISTA/FRANGO',
                          'LINGUIÇA MISTA DE FRANGO',
                          '01',
                          '2023-12-12',
                          3,
                          NULL,
                          25
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          11,
                          'MISTÃO',
                          'CARNE, FRANGO',
                          '01',
                          '2023-12-12',
                          1,
                          NULL,
                          35
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          12,
                          'OVO DE CODORNA',
                          'OVo DE CODORNA',
                          '01',
                          '2023-12-12',
                          1,
                          NULL,
                          20
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          13,
                          'QUIELO ASSADO NA BRASA COM MELAÇO DE CANA',
                          'QUEIJO E COALHO ASSADO',
                          '01',
                          '2023-12-12',
                          1,
                          NULL,
                          20
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          14,
                          'xxxxxx      xxxxxxx',
                          'xxxxxxxxxxxxxxxxxxxx',
                          '2',
                          '2023-12-29',
                          1,
                          1,
                          10
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          17,
                          'salada tropical',
                          'aaaaaaaaaa
bbbbbbbbbbbbbb
ccccccccccccccc',
                          '02',
                          '2023-12-28',
                          7,
                          1,
                          5
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          18,
                          'salada de alface completa',
                          'vvvvvvv
bbbbbbbbbbbbb
bbbbbbb',
                          '1',
                          '2023-12-28',
                          7,
                          1,
                          8
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          19,
                          'salada completa',
                          'aaaaaaaaaa
bbbbbbbb
ccccccc
dddddddddddd',
                          '01',
                          '2023-12-28',
                          7,
                          1,
                          5
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          20,
                          'tira gosto 02',
                          'aaaaaaaaa ssssssss ddddd',
                          '2',
                          '2023-12-30',
                          1,
                          1,
                          10
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          21,
                          'pirão de mocoto',
                          'mocoto, bucho',
                          '3',
                          '2023-12-28',
                          2,
                          1,
                          40
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          22,
                          'macarronada',
                          'macarrao queijo parmesão',
                          '3',
                          '2023-12-29',
                          2,
                          1,
                          55
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          23,
                          'lasanha a bolonhesa',
                          'macarra, carnr moida',
                          '4',
                          '2023-12-29',
                          2,
                          1,
                          60
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          24,
                          'peixe frito',
                          'qwerty',
                          '3',
                          '2023-12-29',
                          1,
                          1,
                          30
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          25,
                          'agulha fritas',
                          'agulha branca',
                          '10',
                          '2023-12-29',
                          3,
                          1,
                          50
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          26,
                          'coca cola 2l',
                          'coca cola',
                          '1',
                          '2023-12-29',
                          10,
                          1,
                          8
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          27,
                          'tripa assada',
                          'tripa de porco',
                          '1',
                          '2023-12-29',
                          1,
                          1,
                          10
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          28,
                          'cerveja  skol lata',
                          'cerveja skol',
                          '1',
                          '2023-12-30',
                          11,
                          1,
                          6
                      );

INSERT INTO core_menu (
                          id,
                          item_menu,
                          descricao,
                          porcao,
                          data_cad,
                          grupomen_id,
                          usuario_id,
                          preco
                      )
                      VALUES (
                          30,
                          'Guarana 1L',
                          'aaaaaaa',
                          '01',
                          '2024-01-18',
                          10,
                          1,
                          8
                      );


-- Table: core_mesas
CREATE TABLE core_mesas (
    id          INTEGER      NOT NULL
                             PRIMARY KEY AUTOINCREMENT,
    descricao   VARCHAR (50) NOT NULL,
    status_mesa VARCHAR (1)  NOT NULL,
    data_cad    DATE         NOT NULL,
    usuario_id  BIGINT
                             REFERENCES core_userprofile (id) DEFERRABLE INITIALLY DEFERRED
);

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           1,
                           'MESA 01',
                           'l',
                           '2023-12-28',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           2,
                           'MESA 02',
                           'l',
                           '2023-12-28',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           3,
                           'MESA 03',
                           'l',
                           '2024-02-11',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           4,
                           'MESA04',
                           'l',
                           '2024-01-30',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           5,
                           'MESA 05',
                           'l',
                           '2024-01-05',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           6,
                           'MESA 06',
                           'l',
                           '2023-12-12',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           7,
                           'MESA 07',
                           'l',
                           '2023-12-12',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           8,
                           'MESA 08',
                           'l',
                           '2023-12-26',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           9,
                           'MESA 09',
                           'l',
                           '2023-12-12',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           10,
                           'MESA 10',
                           'l',
                           '2024-01-08',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           11,
                           'Mesa especial',
                           'l',
                           '2024-01-16',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           12,
                           'mesa 100',
                           'l',
                           '2024-01-16',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           13,
                           'mesa 100',
                           'l',
                           '2024-01-16',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           14,
                           'mesa 100',
                           'l',
                           '2024-01-16',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           15,
                           'Mesa vip01',
                           'l',
                           '2024-01-16',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           16,
                           'mesa vip02',
                           'l',
                           '2024-01-16',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           17,
                           'mesa Especial',
                           'l',
                           '2024-01-16',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           18,
                           'mesa 200',
                           'l',
                           '2024-01-16',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           19,
                           'mesa 300',
                           'l',
                           '2024-01-16',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           20,
                           'mesa 400',
                           'o',
                           '2024-01-19',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           21,
                           'Mesa 500',
                           'l',
                           '2024-01-16',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           22,
                           'mesa cceciilia',
                           'l',
                           '2024-01-16',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           23,
                           'mesa vip 200',
                           'l',
                           '2024-01-16',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           24,
                           'mesa  vip 500',
                           'l',
                           '2024-01-16',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           25,
                           'mesa nando',
                           'l',
                           '2024-01-16',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           26,
                           'mesa central',
                           'r',
                           '2024-01-16',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           27,
                           'nesa superior',
                           'l',
                           '2024-01-16',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           28,
                           'nesa superior',
                           'l',
                           '2024-01-16',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           29,
                           'mesa luiza 100',
                           'l',
                           '2024-01-19',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           30,
                           'mesa luiza',
                           'l',
                           '2024-01-16',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           31,
                           'mesa balcãao',
                           'r',
                           '2024-01-19',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           32,
                           'mesa  lago',
                           'l',
                           '2024-01-17',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           33,
                           'mesa teste',
                           'o',
                           '2024-01-19',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           36,
                           'mesa vip 800',
                           'l',
                           '2024-01-18',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           37,
                           'mesa fernando',
                           'l',
                           '2024-01-30',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           38,
                           'mesa 123',
                           'l',
                           '2024-01-30',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           39,
                           'maria luiza',
                           'l',
                           '2024-02-05',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           40,
                           'comanda 500',
                           'l',
                           '2024-02-09',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           41,
                           'Fernando mesa 10',
                           'l',
                           '2024-02-11',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           42,
                           'nova comanda',
                           'l',
                           '2024-02-12',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           43,
                           'fernando 01',
                           'l',
                           '2024-02-12',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           44,
                           'mesa nova',
                           'l',
                           '2024-02-16',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           45,
                           'teste fernando',
                           'l',
                           '2024-02-16',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           46,
                           'teste comanda',
                           'l',
                           '2024-02-17',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           47,
                           'testa comanda 02',
                           'l',
                           '2024-02-19',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           48,
                           'comanda 03',
                           'l',
                           '2024-02-19',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           49,
                           'teste comanda 05',
                           'l',
                           '2024-02-19',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           50,
                           'teste comanda 6',
                           'l',
                           '2024-02-19',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           51,
                           'teste comanda 6',
                           'l',
                           '2024-02-19',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           52,
                           'teste comanda 10',
                           'l',
                           '2024-02-19',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           53,
                           'comanda teste 11',
                           'l',
                           '2024-02-19',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           54,
                           'comanda teste 12',
                           'l',
                           '2024-02-19',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           55,
                           'comnada teste 13',
                           'l',
                           '2024-02-19',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           56,
                           'teste comanda 14',
                           'l',
                           '2024-02-20',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           57,
                           'teste comanda 15',
                           'l',
                           '2024-02-20',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           58,
                           'teste comanda 17',
                           'l',
                           '2024-02-20',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           59,
                           'teste comanda 18',
                           'l',
                           '2024-02-20',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           60,
                           'teste comanda 20',
                           'l',
                           '2024-02-20',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           61,
                           'teste comanda 21',
                           'l',
                           '2024-02-20',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           62,
                           'teste comanda 22',
                           'l',
                           '2024-02-20',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           63,
                           'teste comanda 24',
                           'o',
                           '2024-02-20',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           64,
                           'Hogelio',
                           'l',
                           '2024-02-24',
                           NULL
                       );

INSERT INTO core_mesas (
                           id,
                           descricao,
                           status_mesa,
                           data_cad,
                           usuario_id
                       )
                       VALUES (
                           65,
                           'Rogelio',
                           'o',
                           '2024-02-24',
                           NULL
                       );


-- Table: core_pagamento
CREATE TABLE core_pagamento (
    id             INTEGER       NOT NULL
                                 PRIMARY KEY AUTOINCREMENT,
    valor          DECIMAL       NOT NULL,
    data_pagamento DATE          NOT NULL,
    conta_id_id    INTEGER       NOT NULL
                                 REFERENCES core_conta (id) DEFERRABLE INITIALLY DEFERRED,
    observacao     VARCHAR (200) NOT NULL,
    usuario_id     BIGINT
                                 REFERENCES core_userprofile (id) DEFERRABLE INITIALLY DEFERRED
);


-- Table: core_produto
CREATE TABLE core_produto (
    id            INTEGER      NOT NULL
                               PRIMARY KEY AUTOINCREMENT,
    nome          VARCHAR (80) NOT NULL,
    quantidade    INTEGER      NOT NULL,
    valor         DECIMAL      NOT NULL,
    data_cad      DATE         NOT NULL,
    data_atu      DATE         NOT NULL,
    quant_unidade INTEGER      NOT NULL,
    grupo_id      BIGINT
                               REFERENCES core_grupos (id) DEFERRABLE INITIALLY DEFERRED,
    unidade_id    BIGINT
                               REFERENCES core_unidades (id) DEFERRABLE INITIALLY DEFERRED,
    usuario_id    BIGINT
                               REFERENCES core_userprofile (id) DEFERRABLE INITIALLY DEFERRED
);


-- Table: core_saidas
CREATE TABLE core_saidas (
    id         INTEGER NOT NULL
                       PRIMARY KEY AUTOINCREMENT,
    saida      INTEGER NOT NULL,
    data_saida DATE    NOT NULL,
    data_cad   DATE    NOT NULL,
    produto_id BIGINT
                       REFERENCES core_produto (id) DEFERRABLE INITIALLY DEFERRED,
    usuario_id BIGINT
                       REFERENCES core_userprofile (id) DEFERRABLE INITIALLY DEFERRED
);


-- Table: core_tipomovimento
CREATE TABLE core_tipomovimento (
    id   INTEGER      NOT NULL
                      PRIMARY KEY AUTOINCREMENT,
    nome VARCHAR (30) NOT NULL
);

INSERT INTO core_tipomovimento (
                                   id,
                                   nome
                               )
                               VALUES (
                                   1,
                                   'Saida'
                               );

INSERT INTO core_tipomovimento (
                                   id,
                                   nome
                               )
                               VALUES (
                                   2,
                                   'Entrada'
                               );


-- Table: core_unidades
CREATE TABLE core_unidades (
    id         INTEGER      NOT NULL
                            PRIMARY KEY AUTOINCREMENT,
    descricao  VARCHAR (50) NOT NULL,
    abrevia    VARCHAR (10) NOT NULL,
    data_cad   DATE         NOT NULL,
    usuario_id BIGINT
                            REFERENCES core_userprofile (id) DEFERRABLE INITIALLY DEFERRED
);


-- Table: core_userprofile
CREATE TABLE core_userprofile (
    id      INTEGER NOT NULL
                    PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL
                    UNIQUE
                    REFERENCES auth_user (id) DEFERRABLE INITIALLY DEFERRED
);

INSERT INTO core_userprofile (
                                 id,
                                 user_id
                             )
                             VALUES (
                                 1,
                                 2
                             );


-- Table: django_admin_log
CREATE TABLE django_admin_log (
    id              INTEGER             NOT NULL
                                        PRIMARY KEY AUTOINCREMENT,
    object_id       TEXT,
    object_repr     VARCHAR (200)       NOT NULL,
    action_flag     [SMALLINT UNSIGNED] NOT NULL
                                        CHECK ("action_flag" >= 0),
    change_message  TEXT                NOT NULL,
    content_type_id INTEGER
                                        REFERENCES django_content_type (id) DEFERRABLE INITIALLY DEFERRED,
    user_id         INTEGER             NOT NULL
                                        REFERENCES auth_user (id) DEFERRABLE INITIALLY DEFERRED,
    action_time     DATETIME            NOT NULL
);

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 1,
                                 '1',
                                 'Menu object (1)',
                                 1,
                                 '[{"added": {}}]',
                                 15,
                                 1,
                                 '2023-12-12 13:02:49.193118'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 2,
                                 '2',
                                 'Menu object (2)',
                                 1,
                                 '[{"added": {}}]',
                                 15,
                                 1,
                                 '2023-12-12 13:03:45.800309'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 3,
                                 '3',
                                 'Menu object (3)',
                                 1,
                                 '[{"added": {}}]',
                                 15,
                                 1,
                                 '2023-12-12 13:04:47.069051'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 4,
                                 '4',
                                 'Menu object (4)',
                                 1,
                                 '[{"added": {}}]',
                                 15,
                                 1,
                                 '2023-12-12 13:05:39.084139'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 5,
                                 '5',
                                 'Menu object (5)',
                                 1,
                                 '[{"added": {}}]',
                                 15,
                                 1,
                                 '2023-12-12 13:06:48.075203'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 6,
                                 '6',
                                 'Menu object (6)',
                                 1,
                                 '[{"added": {}}]',
                                 15,
                                 1,
                                 '2023-12-12 13:07:20.576848'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 7,
                                 '7',
                                 'Menu object (7)',
                                 1,
                                 '[{"added": {}}]',
                                 15,
                                 1,
                                 '2023-12-12 13:07:55.376603'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 8,
                                 '8',
                                 'Menu object (8)',
                                 1,
                                 '[{"added": {}}]',
                                 15,
                                 1,
                                 '2023-12-12 13:08:15.019805'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 9,
                                 '9',
                                 'Menu object (9)',
                                 1,
                                 '[{"added": {}}]',
                                 15,
                                 1,
                                 '2023-12-12 13:08:54.484851'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 10,
                                 '10',
                                 'Menu object (10)',
                                 1,
                                 '[{"added": {}}]',
                                 15,
                                 1,
                                 '2023-12-12 13:09:32.486673'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 11,
                                 '11',
                                 'Menu object (11)',
                                 1,
                                 '[{"added": {}}]',
                                 15,
                                 1,
                                 '2023-12-12 13:11:14.202974'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 12,
                                 '12',
                                 'Menu object (12)',
                                 1,
                                 '[{"added": {}}]',
                                 15,
                                 1,
                                 '2023-12-12 13:11:45.008184'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 13,
                                 '13',
                                 'Menu object (13)',
                                 1,
                                 '[{"added": {}}]',
                                 15,
                                 1,
                                 '2023-12-12 13:12:53.835938'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 14,
                                 '1',
                                 'MESA 01',
                                 1,
                                 '[{"added": {}}]',
                                 18,
                                 1,
                                 '2023-12-12 13:16:36.335666'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 15,
                                 '2',
                                 'MESA 02',
                                 1,
                                 '[{"added": {}}]',
                                 18,
                                 1,
                                 '2023-12-12 13:16:47.261799'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 16,
                                 '3',
                                 'MESA 03',
                                 1,
                                 '[{"added": {}}]',
                                 18,
                                 1,
                                 '2023-12-12 13:16:55.741032'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 17,
                                 '4',
                                 'MESA04',
                                 1,
                                 '[{"added": {}}]',
                                 18,
                                 1,
                                 '2023-12-12 13:17:04.541481'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 18,
                                 '5',
                                 'MESA 05',
                                 1,
                                 '[{"added": {}}]',
                                 18,
                                 1,
                                 '2023-12-12 13:17:12.143654'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 19,
                                 '6',
                                 'MESA 06',
                                 1,
                                 '[{"added": {}}]',
                                 18,
                                 1,
                                 '2023-12-12 13:17:24.117752'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 20,
                                 '7',
                                 'MESA 07',
                                 1,
                                 '[{"added": {}}]',
                                 18,
                                 1,
                                 '2023-12-12 13:17:36.575147'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 21,
                                 '8',
                                 'MESA 08',
                                 1,
                                 '[{"added": {}}]',
                                 18,
                                 1,
                                 '2023-12-12 13:17:44.968315'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 22,
                                 '9',
                                 'MESA 09',
                                 1,
                                 '[{"added": {}}]',
                                 18,
                                 1,
                                 '2023-12-12 13:17:53.620928'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 23,
                                 '10',
                                 'MESA 10',
                                 1,
                                 '[{"added": {}}]',
                                 18,
                                 1,
                                 '2023-12-12 13:18:01.551750'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 24,
                                 '1',
                                 'Tira Gosto',
                                 1,
                                 '[{"added": {}}]',
                                 19,
                                 1,
                                 '2023-12-12 19:51:40.056315'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 25,
                                 '2',
                                 'Refeições',
                                 1,
                                 '[{"added": {}}]',
                                 19,
                                 1,
                                 '2023-12-12 19:52:09.193813'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 26,
                                 '3',
                                 'Petiscos',
                                 1,
                                 '[{"added": {}}]',
                                 19,
                                 1,
                                 '2023-12-12 19:52:39.935388'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 27,
                                 '4',
                                 'Porção',
                                 1,
                                 '[{"added": {}}]',
                                 19,
                                 1,
                                 '2023-12-12 19:52:51.888242'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 28,
                                 '5',
                                 'Café da Manhã',
                                 1,
                                 '[{"added": {}}]',
                                 19,
                                 1,
                                 '2023-12-12 19:53:36.218578'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 29,
                                 '6',
                                 'Porções (250Gr)',
                                 1,
                                 '[{"added": {}}]',
                                 19,
                                 1,
                                 '2023-12-12 19:55:49.387480'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 30,
                                 '7',
                                 'Saladas',
                                 1,
                                 '[{"added": {}}]',
                                 19,
                                 1,
                                 '2023-12-12 19:57:57.917823'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 31,
                                 '8',
                                 'Sucos',
                                 1,
                                 '[{"added": {}}]',
                                 19,
                                 1,
                                 '2023-12-12 19:58:06.593376'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 32,
                                 '9',
                                 'Sanduiches',
                                 1,
                                 '[{"added": {}}]',
                                 19,
                                 1,
                                 '2023-12-12 19:58:17.521641'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 33,
                                 '10',
                                 'Refrigerantes',
                                 1,
                                 '[{"added": {}}]',
                                 19,
                                 1,
                                 '2023-12-12 19:58:28.892379'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 34,
                                 '11',
                                 'Bebidas',
                                 1,
                                 '[{"added": {}}]',
                                 19,
                                 1,
                                 '2023-12-12 19:58:37.492805'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 35,
                                 '13',
                                 'Menu object (13)',
                                 2,
                                 '[{"changed": {"fields": ["Grupomen"]}}]',
                                 15,
                                 1,
                                 '2023-12-12 20:00:19.228152'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 36,
                                 '12',
                                 'Menu object (12)',
                                 2,
                                 '[{"changed": {"fields": ["Grupomen", "Descricao"]}}]',
                                 15,
                                 1,
                                 '2023-12-12 20:00:58.672690'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 37,
                                 '11',
                                 'Menu object (11)',
                                 2,
                                 '[{"changed": {"fields": ["Grupomen"]}}]',
                                 15,
                                 1,
                                 '2023-12-12 20:01:18.917665'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 38,
                                 '1',
                                 'gerencia',
                                 1,
                                 '[{"added": {}}]',
                                 3,
                                 1,
                                 '2023-12-13 13:20:44.104666'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 39,
                                 '2',
                                 'geregte',
                                 1,
                                 '[{"added": {}}]',
                                 4,
                                 1,
                                 '2023-12-13 13:28:33.017551'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 40,
                                 '3',
                                 'garcon01',
                                 1,
                                 '[{"added": {}}]',
                                 4,
                                 1,
                                 '2023-12-13 13:31:52.243013'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 41,
                                 '4',
                                 'jose',
                                 1,
                                 '[{"added": {}}]',
                                 4,
                                 1,
                                 '2023-12-13 13:33:07.283430'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 42,
                                 '5',
                                 'pedro',
                                 1,
                                 '[{"added": {}}]',
                                 4,
                                 1,
                                 '2023-12-13 13:34:59.505724'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 43,
                                 '2',
                                 'garcon',
                                 1,
                                 '[{"added": {}}]',
                                 3,
                                 1,
                                 '2023-12-13 13:41:43.749158'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 44,
                                 '2',
                                 'gerente',
                                 2,
                                 '[{"changed": {"fields": ["Username", "First name", "Last name", "Groups"]}}]',
                                 4,
                                 1,
                                 '2023-12-13 13:44:08.911520'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 45,
                                 '4',
                                 'jose',
                                 2,
                                 '[{"changed": {"fields": ["First name", "Last name", "Email address", "Groups"]}}]',
                                 4,
                                 1,
                                 '2023-12-13 13:47:00.662656'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 46,
                                 '5',
                                 'pedro',
                                 2,
                                 '[{"changed": {"fields": ["First name", "Last name", "Email address", "Groups"]}}]',
                                 4,
                                 1,
                                 '2023-12-13 13:48:34.300285'
                             );

INSERT INTO django_admin_log (
                                 id,
                                 object_id,
                                 object_repr,
                                 action_flag,
                                 change_message,
                                 content_type_id,
                                 user_id,
                                 action_time
                             )
                             VALUES (
                                 47,
                                 '2',
                                 'gerente',
                                 2,
                                 '[{"changed": {"fields": ["password"]}}]',
                                 4,
                                 1,
                                 '2023-12-13 13:52:06.421942'
                             );


-- Table: django_content_type
CREATE TABLE django_content_type (
    id        INTEGER       NOT NULL
                            PRIMARY KEY AUTOINCREMENT,
    app_label VARCHAR (100) NOT NULL,
    model     VARCHAR (100) NOT NULL
);

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    1,
                                    'admin',
                                    'logentry'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    2,
                                    'auth',
                                    'permission'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    3,
                                    'auth',
                                    'group'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    4,
                                    'auth',
                                    'user'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    5,
                                    'contenttypes',
                                    'contenttype'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    6,
                                    'sessions',
                                    'session'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    7,
                                    'core',
                                    'clientes'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    8,
                                    'core',
                                    'unidades'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    9,
                                    'core',
                                    'grupos'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    10,
                                    'core',
                                    'entradas'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    11,
                                    'core',
                                    'fornecedor'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    12,
                                    'core',
                                    'saidas'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    13,
                                    'core',
                                    'itemcomanda'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    14,
                                    'core',
                                    'comanda'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    15,
                                    'core',
                                    'menu'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    16,
                                    'core',
                                    'userprofile'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    17,
                                    'core',
                                    'produto'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    18,
                                    'core',
                                    'mesas'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    19,
                                    'core',
                                    'grupomenu'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    20,
                                    'core',
                                    'tipomovimentacao'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    21,
                                    'core',
                                    'movimentacao'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    22,
                                    'core',
                                    'conta'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    23,
                                    'core',
                                    'contaspagar'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    24,
                                    'core',
                                    'formapgto'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    25,
                                    'core',
                                    'pagamento'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    26,
                                    'core',
                                    'caixa'
                                );

INSERT INTO django_content_type (
                                    id,
                                    app_label,
                                    model
                                )
                                VALUES (
                                    27,
                                    'core',
                                    'tipomovimento'
                                );


-- Table: django_migrations
CREATE TABLE django_migrations (
    id      INTEGER       NOT NULL
                          PRIMARY KEY AUTOINCREMENT,
    app     VARCHAR (255) NOT NULL,
    name    VARCHAR (255) NOT NULL,
    applied DATETIME      NOT NULL
);

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  1,
                                  'contenttypes',
                                  '0001_initial',
                                  '2023-12-01 18:46:21.277596'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  2,
                                  'auth',
                                  '0001_initial',
                                  '2023-12-01 18:46:21.986793'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  3,
                                  'admin',
                                  '0001_initial',
                                  '2023-12-01 18:46:22.515622'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  4,
                                  'admin',
                                  '0002_logentry_remove_auto_add',
                                  '2023-12-01 18:46:22.778755'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  5,
                                  'admin',
                                  '0003_logentry_add_action_flag_choices',
                                  '2023-12-01 18:46:23.315528'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  6,
                                  'contenttypes',
                                  '0002_remove_content_type_name',
                                  '2023-12-01 18:46:23.639364'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  7,
                                  'auth',
                                  '0002_alter_permission_name_max_length',
                                  '2023-12-01 18:46:24.000665'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  8,
                                  'auth',
                                  '0003_alter_user_email_max_length',
                                  '2023-12-01 18:46:24.534139'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  9,
                                  'auth',
                                  '0004_alter_user_username_opts',
                                  '2023-12-01 18:46:24.863427'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  10,
                                  'auth',
                                  '0005_alter_user_last_login_null',
                                  '2023-12-01 18:46:25.171325'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  11,
                                  'auth',
                                  '0006_require_contenttypes_0002',
                                  '2023-12-01 18:46:25.705316'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  12,
                                  'auth',
                                  '0007_alter_validators_add_error_messages',
                                  '2023-12-01 18:46:26.138162'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  13,
                                  'auth',
                                  '0008_alter_user_username_max_length',
                                  '2023-12-01 18:46:26.569610'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  14,
                                  'auth',
                                  '0009_alter_user_last_name_max_length',
                                  '2023-12-01 18:46:27.167974'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  15,
                                  'auth',
                                  '0010_alter_group_name_max_length',
                                  '2023-12-01 18:46:27.690990'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  16,
                                  'auth',
                                  '0011_update_proxy_permissions',
                                  '2023-12-01 18:46:28.001313'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  17,
                                  'auth',
                                  '0012_alter_user_first_name_max_length',
                                  '2023-12-01 18:46:28.474599'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  18,
                                  'sessions',
                                  '0001_initial',
                                  '2023-12-01 18:46:29.314412'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  19,
                                  'core',
                                  '0001_initial',
                                  '2023-12-10 02:07:02.192808'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  20,
                                  'core',
                                  '0002_grupomenu',
                                  '2023-12-12 18:02:21.549766'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  21,
                                  'core',
                                  '0003_menu_grupomen_alter_grupomenu_descricao',
                                  '2023-12-12 18:52:17.121771'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  22,
                                  'core',
                                  '0004_menu_preco',
                                  '2023-12-15 01:49:59.526508'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  23,
                                  'core',
                                  '0005_clientes_usuario_fornecedor_usuario_grupos_usuario_and_more',
                                  '2023-12-15 01:50:00.555276'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  24,
                                  'core',
                                  '0006_remove_userprofile_profile_user_id',
                                  '2023-12-28 19:54:00.636671'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  25,
                                  'core',
                                  '0007_alter_menu_preco',
                                  '2023-12-29 01:27:05.899721'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  26,
                                  'core',
                                  '0008_tipomovimentacao_itemcomanda_status_movimentacao',
                                  '2024-01-07 15:52:29.706105'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  27,
                                  'core',
                                  '0009_conta_contaspagar_formapgto_pagamento_conta_titulo',
                                  '2024-01-07 15:52:29.908756'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  28,
                                  'core',
                                  '0010_pagamento_observacao',
                                  '2024-02-09 18:06:11.218248'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  29,
                                  'core',
                                  '0011_comanda_descricao',
                                  '2024-02-16 13:20:58.159351'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  30,
                                  'core',
                                  '0012_alter_comanda_hora_fim',
                                  '2024-02-16 13:20:58.510611'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  31,
                                  'core',
                                  '0013_alter_comanda_hora_fim_alter_comanda_hora_inicio',
                                  '2024-02-16 13:20:58.966422'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  32,
                                  'core',
                                  '0014_alter_comanda_data_cad_alter_comanda_hora_fim_and_more',
                                  '2024-02-16 13:20:59.200013'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  33,
                                  'core',
                                  '0015_alter_comanda_hora_fim_alter_comanda_hora_inicio',
                                  '2024-02-18 01:24:37.092771'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  34,
                                  'core',
                                  '0016_caixa_conta_usuario_pagamento_usuario_and_more',
                                  '2024-02-19 19:41:53.926605'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  35,
                                  'core',
                                  '0017_alter_tipomovimentacao_nome',
                                  '2024-02-20 19:26:58.397411'
                              );

INSERT INTO django_migrations (
                                  id,
                                  app,
                                  name,
                                  applied
                              )
                              VALUES (
                                  36,
                                  'core',
                                  '0018_tipomovimento_alter_caixa_tipo_and_more',
                                  '2024-02-20 19:26:58.725347'
                              );


-- Table: django_session
CREATE TABLE django_session (
    session_key  VARCHAR (40) NOT NULL
                              PRIMARY KEY,
    session_data TEXT         NOT NULL,
    expire_date  DATETIME     NOT NULL
);

INSERT INTO django_session (
                               session_key,
                               session_data,
                               expire_date
                           )
                           VALUES (
                               'ca1rw2a1nvq9ukwno0gjgarsf1sjid9p',
                               '.eJxVjL0OwjAQg98lM4p6aX4Z2XmG6HKXkgJKpaadEO8OkTqABw_-bL9ExH0rcW95jTOLs1Di9JslpEeuHfAd622RtNRtnZPsFXnQJq8L5-fl6P4dFGzlux7BOW2DMmYEVN4ikCHopjgxZwuDAs6eQkiJGNyk86C7YEKPIN4fxHc3iw:1rPRlv:-_SyDJcI39zNqJgexFXccu74jDTdo9hkstdCON0_w9I',
                               '2024-01-29 18:33:19.422137'
                           );

INSERT INTO django_session (
                               session_key,
                               session_data,
                               expire_date
                           )
                           VALUES (
                               'iee7zpxwlr85kncqju8ml8b2vlklrqda',
                               '.eJxVjL0OwjAQg98lM4p6aX4Z2XmG6HKXkgJKpaadEO8OkTqABw_-bL9ExH0rcW95jTOLs1Di9JslpEeuHfAd622RtNRtnZPsFXnQJq8L5-fl6P4dFGzlux7BOW2DMmYEVN4ikCHopjgxZwuDAs6eQkiJGNyk86C7YEKPIN4fxHc3iw:1rUXYg:Sk_PipVAzU_bv1wQr3oAnBagcWDVv0rIV6XjepTVOPI',
                               '2024-02-12 19:44:42.053167'
                           );

INSERT INTO django_session (
                               session_key,
                               session_data,
                               expire_date
                           )
                           VALUES (
                               'f2n6fh016lb7uimbovi4wk73t19meyk9',
                               '.eJxVjL0OwjAQg98lM4p6aX4Z2XmG6HKXkgJKpaadEO8OkTqABw_-bL9ExH0rcW95jTOLs1Di9JslpEeuHfAd622RtNRtnZPsFXnQJq8L5-fl6P4dFGzlux7BOW2DMmYEVN4ikCHopjgxZwuDAs6eQkiJGNyk86C7YEKPIN4fxHc3iw:1rVyov:jGpKW-F2rJQ8e8HZMensFsOEng0Ag2hjDsoRKxy84u8',
                               '2024-02-16 19:03:25.983144'
                           );

INSERT INTO django_session (
                               session_key,
                               session_data,
                               expire_date
                           )
                           VALUES (
                               'rrxgiv7fbubvd11gsxrv776330zyrm1y',
                               '.eJxVjL0OwjAQg98lM4p6aX4Z2XmG6HKXkgJKpaadEO8OkTqABw_-bL9ExH0rcW95jTOLs1Di9JslpEeuHfAd622RtNRtnZPsFXnQJq8L5-fl6P4dFGzlux7BOW2DMmYEVN4ikCHopjgxZwuDAs6eQkiJGNyk86C7YEKPIN4fxHc3iw:1rcaMA:jfepBMDr_TfUyXYKtcAtzA4_8_wvcHW80otbka_seVU',
                               '2024-03-06 00:21:02.683372'
                           );


-- Index: auth_group_permissions_group_id_b120cbf9
CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON auth_group_permissions (
    "group_id"
);


-- Index: auth_group_permissions_group_id_permission_id_0cd325b0_uniq
CREATE UNIQUE INDEX auth_group_permissions_group_id_permission_id_0cd325b0_uniq ON auth_group_permissions (
    "group_id",
    "permission_id"
);


-- Index: auth_group_permissions_permission_id_84c5c92e
CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON auth_group_permissions (
    "permission_id"
);


-- Index: auth_permission_content_type_id_2f476e4b
CREATE INDEX auth_permission_content_type_id_2f476e4b ON auth_permission (
    "content_type_id"
);


-- Index: auth_permission_content_type_id_codename_01ab375a_uniq
CREATE UNIQUE INDEX auth_permission_content_type_id_codename_01ab375a_uniq ON auth_permission (
    "content_type_id",
    "codename"
);


-- Index: auth_user_groups_group_id_97559544
CREATE INDEX auth_user_groups_group_id_97559544 ON auth_user_groups (
    "group_id"
);


-- Index: auth_user_groups_user_id_6a12ed8b
CREATE INDEX auth_user_groups_user_id_6a12ed8b ON auth_user_groups (
    "user_id"
);


-- Index: auth_user_groups_user_id_group_id_94350c0c_uniq
CREATE UNIQUE INDEX auth_user_groups_user_id_group_id_94350c0c_uniq ON auth_user_groups (
    "user_id",
    "group_id"
);


-- Index: auth_user_user_permissions_permission_id_1fbb5f2c
CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON auth_user_user_permissions (
    "permission_id"
);


-- Index: auth_user_user_permissions_user_id_a95ead1b
CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON auth_user_user_permissions (
    "user_id"
);


-- Index: auth_user_user_permissions_user_id_permission_id_14a6b632_uniq
CREATE UNIQUE INDEX auth_user_user_permissions_user_id_permission_id_14a6b632_uniq ON auth_user_user_permissions (
    "user_id",
    "permission_id"
);


-- Index: core_caixa_forma_pgto_caixa_id_39bf446e
CREATE INDEX core_caixa_forma_pgto_caixa_id_39bf446e ON core_caixa (
    "forma_pgto_caixa_id"
);


-- Index: core_caixa_tipo_id_a348c1eb
CREATE INDEX core_caixa_tipo_id_a348c1eb ON core_caixa (
    "tipo_id"
);


-- Index: core_caixa_usuario_id_2c52f75c
CREATE INDEX core_caixa_usuario_id_2c52f75c ON core_caixa (
    "usuario_id"
);


-- Index: core_clientes_usuario_id_37fff405
CREATE INDEX core_clientes_usuario_id_37fff405 ON core_clientes (
    "usuario_id"
);


-- Index: core_comanda_mesa_id_92aad455
CREATE INDEX core_comanda_mesa_id_92aad455 ON core_comanda (
    "mesa_id"
);


-- Index: core_comanda_usuario_id_90886b80
CREATE INDEX core_comanda_usuario_id_90886b80 ON core_comanda (
    "usuario_id"
);


-- Index: core_conta_titulo_id_a186b1f4
CREATE INDEX core_conta_titulo_id_a186b1f4 ON core_conta (
    "titulo_id"
);


-- Index: core_conta_usuario_id_45038a68
CREATE INDEX core_conta_usuario_id_45038a68 ON core_conta (
    "usuario_id"
);


-- Index: core_entradas_fornecedor_id_fef65831
CREATE INDEX core_entradas_fornecedor_id_fef65831 ON core_entradas (
    "fornecedor_id"
);


-- Index: core_entradas_produto_id_e5b7d82b
CREATE INDEX core_entradas_produto_id_e5b7d82b ON core_entradas (
    "produto_id"
);


-- Index: core_entradas_usuario_id_a033e813
CREATE INDEX core_entradas_usuario_id_a033e813 ON core_entradas (
    "usuario_id"
);


-- Index: core_fornecedor_usuario_id_3767530a
CREATE INDEX core_fornecedor_usuario_id_3767530a ON core_fornecedor (
    "usuario_id"
);


-- Index: core_grupos_usuario_id_516d47dc
CREATE INDEX core_grupos_usuario_id_516d47dc ON core_grupos (
    "usuario_id"
);


-- Index: core_itemcomanda_comanda_id_6848ec48
CREATE INDEX core_itemcomanda_comanda_id_6848ec48 ON core_itemcomanda (
    "comanda_id"
);


-- Index: core_itemcomanda_item_menu_id_d16bbd93
CREATE INDEX core_itemcomanda_item_menu_id_d16bbd93 ON core_itemcomanda (
    "item_menu_id"
);


-- Index: core_menu_grupomen_id_539823ef
CREATE INDEX core_menu_grupomen_id_539823ef ON core_menu (
    "grupomen_id"
);


-- Index: core_menu_usuario_id_ecd2ec3d
CREATE INDEX core_menu_usuario_id_ecd2ec3d ON core_menu (
    "usuario_id"
);


-- Index: core_mesas_usuario_id_e5911052
CREATE INDEX core_mesas_usuario_id_e5911052 ON core_mesas (
    "usuario_id"
);


-- Index: core_pagamento_conta_id_id_67ae79df
CREATE INDEX core_pagamento_conta_id_id_67ae79df ON core_pagamento (
    "conta_id_id"
);


-- Index: core_pagamento_usuario_id_46320d47
CREATE INDEX core_pagamento_usuario_id_46320d47 ON core_pagamento (
    "usuario_id"
);


-- Index: core_produto_grupo_id_f5658232
CREATE INDEX core_produto_grupo_id_f5658232 ON core_produto (
    "grupo_id"
);


-- Index: core_produto_unidade_id_a2d392ec
CREATE INDEX core_produto_unidade_id_a2d392ec ON core_produto (
    "unidade_id"
);


-- Index: core_produto_usuario_id_f1adb602
CREATE INDEX core_produto_usuario_id_f1adb602 ON core_produto (
    "usuario_id"
);


-- Index: core_saidas_produto_id_98371ea1
CREATE INDEX core_saidas_produto_id_98371ea1 ON core_saidas (
    "produto_id"
);


-- Index: core_saidas_usuario_id_2d836a82
CREATE INDEX core_saidas_usuario_id_2d836a82 ON core_saidas (
    "usuario_id"
);


-- Index: core_unidades_usuario_id_386adcf8
CREATE INDEX core_unidades_usuario_id_386adcf8 ON core_unidades (
    "usuario_id"
);


-- Index: django_admin_log_content_type_id_c4bce8eb
CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON django_admin_log (
    "content_type_id"
);


-- Index: django_admin_log_user_id_c564eba6
CREATE INDEX django_admin_log_user_id_c564eba6 ON django_admin_log (
    "user_id"
);


-- Index: django_content_type_app_label_model_76bd3d3b_uniq
CREATE UNIQUE INDEX django_content_type_app_label_model_76bd3d3b_uniq ON django_content_type (
    "app_label",
    "model"
);


-- Index: django_session_expire_date_a5c62663
CREATE INDEX django_session_expire_date_a5c62663 ON django_session (
    "expire_date"
);


COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
