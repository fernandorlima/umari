function abrirPrompt(menuId, mesaId) {
  $("#quantityDialog").modal("show"); // Open the modal dialog
  $("#menuIdInput").val(menuId); // Set the hidden input field with menu ID
  $("#mesaIdInput").val(mesaId); // Set the hidden input field with mesa ID
}

function salvarQuantidade() {
  const menuId = $("#menuIdInput").val(); // Get the menu ID from the hidden input
  const mesaId = $("#mesaIdInput").val(); // Get the mesa ID from the hidden input
  const quantidade = $("#quantidadeInput").val(); // Get the quantity value from the input field

  // Process the quantity and send it to the server (e.g., using AJAX)
  // Update the UI or display a confirmation message
}
