// core/static/js/atualizar_tabela.js
(function ($) {
  $(document).ready(function () {
    var tabelaItensCadastrados = $('#id_itens_cadastrados');

    // Adicione um evento de mudança ao campo item_menu
    $('#id_item_menu').on('change', function () {
      // Obtém o valor selecionado do item_menu
      var itemMenuId = $(this).val();

      // Adiciona o item à tabela se o valor não for vazio
      if (itemMenuId) {
        var itemMenuDescricao = $('#id_item_menu option:selected').text();
        var quantidade = $('#id_quantidade').val();

        var novaLinha = '<tr><td>' + itemMenuDescricao + '</td><td>' + quantidade + '</td></tr>';
        tabelaItensCadastrados.find('tbody').append(novaLinha);
      }
    });
  });
})(django.jQuery);
