# core/forms.py
from django import forms
from django.utils.safestring import mark_safe
from django.template.loader import render_to_string
from widget_tweaks.templatetags.widget_tweaks import register
from .models import GrupoMenu, Menu, Mesas, Comanda, ItemComanda, Caixa, FormaPgto, FichaTecnica

@register.simple_tag
def render_table(itens_cadastrados):
    return render_to_string('core/tabela_itens_cadastrados.html', {'itens_cadastrados': itens_cadastrados})



class MenuForm(forms.ModelForm):
    ficha_tecnica = forms.ModelChoiceField(queryset=FichaTecnica.objects.all(), required=False)

    def clean_preco(self):
        preco = self.cleaned_data['preco']
        # Se o preço não for fornecido, defina um valor padrão (por exemplo, 0.0)
        return preco if preco is not None else 0.0

    def __init__(self, *args, **kwargs):
        super(MenuForm, self).__init__(*args, **kwargs)


class CadastroItemPedidoForm(forms.ModelForm):
    grupo_menu = forms.ModelChoiceField(
        queryset=GrupoMenu.objects.all(),
        label='Grupo de Menu',
        empty_label='Selecione um grupo de menu'
    )

    item_menu = forms.ModelChoiceField(
        queryset=Menu.objects.all(),
        label='Item de Menu',
        empty_label='Selecione um item de menu'
    )

    quantidade = forms.IntegerField(label='Quantidade')

    class Meta:
        model = ItemComanda
        fields = [ 'item_menu', 'quantidade']

    @property
    def media(self):
        js = ['js/atualizar_tabela.js']
        return forms.Media(js=js)

@register.filter
def add_class(field, css):
    return field.as_widget(attrs={'class': css})

@register.simple_tag
def render_table(itens_cadastrados):
    return render_to_string('core/tabela_itens_cadastrados.html', {'itens_cadastrados': itens_cadastrados})


class MenuDeleteForm(forms.ModelForm):
    class Meta:
        model = Menu
        fields = []  # Sem campos para o formulário de exclusão

    def __init__(self, *args, **kwargs):
        super(MenuDeleteForm, self).__init__(*args, **kwargs)
        self.fields['confirm_delete'] = forms.BooleanField(
            required=True,
            widget=forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            label='Confirmar exclusão'
        )

        ############## Mesas
class MenuForm(forms.ModelForm):
    class Meta:
        model = Menu
        fields = ['item_menu', 'descricao', 'porcao', 'grupomen', 'preco', 'ficha_tecnica', 'id_produto']
        ficha_tecnica = forms.ModelChoiceField(queryset=FichaTecnica.objects.all(), required=False)

    def clean_preco(self):
        preco = self.cleaned_data['preco']
        # Se o preço não for fornecido, defina um valor padrão (por exemplo, 0.0)
        return preco if preco is not None else 0.0

    def __init__(self, *args, **kwargs):
        super(MenuForm, self).__init__(*args, **kwargs)
        # Adicione qualquer personalização adicional aqui, se necessário.
fields = ['grupomen_id','item_menu', 'descricao', 'porcao',  'grupomen_id', 'preco', 'usuario', 'ficha_tecnica', 'id_produto']


class CadastroItemPedidoForm(forms.ModelForm):
    grupo_menu = forms.ModelChoiceField(
        queryset=GrupoMenu.objects.all(),
        label='Grupo de Menu',
        empty_label='Selecione um grupo de menu'
    )

    item_menu = forms.ModelChoiceField(
        queryset=Menu.objects.all(),
        label='Item de Menu',
        empty_label='Selecione um item de menu'
    )

    quantidade = forms.IntegerField(label='Quantidade')

    class Meta:
        model = ItemComanda
        fields = ['grupo_menu', 'item_menu', 'quantidade']

    @property
    def media(self):
        js = ['js/atualizar_tabela.js']
        return forms.Media(js=js)

@register.filter
def add_class(field, css):
    return field.as_widget(attrs={'class': css})

@register.simple_tag
def render_table(itens_cadastrados):
    return render_to_string('core/tabela_itens_cadastrados.html', {'itens_cadastrados': itens_cadastrados})

class MesasForm(forms.ModelForm):
    class Meta:
        model = Mesas
        fields =['descricao']


class MesasDeleteForm(forms.ModelForm):
    class Meta:
        model = Mesas
        fields = []  # Sem campos para o formulário de exclusão

    def __init__(self, *args, **kwargs):
        super(MesasDeleteForm, self).__init__(*args, **kwargs)
        self.fields['confirm_delete'] = forms.BooleanField(
            required=True,
            widget=forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            label='Confirmar exclusão'
        )


class MudarMesaForm(forms.ModelForm):
    class Meta:
        model = Mesas
        fields = []  # Sem campos para o formulário de exclusão


    def __init__(self, *args, **kwargs):
        super(MudarMesaForm, self).__init__(*args, **kwargs)
        self.fields['confirm_mudanca'] = forms.BooleanField(
            required=True,
            widget=forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            label='Confirma Mudança?'
        )


        from .models import Comanda

        class TransferirComandaForm(forms.ModelForm):
            class Meta:
                model = Comanda
                fields = ('mesa_destino',)

            def __init__(self, instance=None, **kwargs):
                super().__init__(instance=instance, **kwargs)
                self.fields['mesa_destino'].queryset = Comanda.objects.filter(status='Aberta')

            def clean(self):
                if self.cleaned_data['mesa_destino'] == self.instance.mesa:
                    raise ValidationError(
                        {'mesa_destino': ['A mesa de destino não pode ser a mesma da comanda atual.']})
                return super().clean()





class PDVForm(forms.Form):
    comanda_selecionada = forms.ModelChoiceField(queryset=Comanda.objects.filter(staus_comanda='a'), empty_label=None, label='Comanda')
    forma_pagamento = forms.ModelChoiceField(queryset=FormaPgto.objects.all(), label='Forma de Pagamento')
    valor_pago = forms.DecimalField(max_digits=10, decimal_places=2, required=False, label='Valor Pago')

    def __init__(self, *args, **kwargs):
        super(PDVForm, self).__init__(*args, **kwargs)
        self.fields['comanda_selecionada'].widget.attrs.update({'class': 'form-control'})
        self.fields['forma_pagamento'].widget.attrs.update({'class': 'form-control'})
        self.fields['valor_pago'].widget.attrs.update({'class': 'form-control'})

# Adicione outras classes de formulário conforme necessário

class ComandasForm(forms.ModelForm):
    class Meta:
        model = Comanda
        fields = ['descricao', 'mesa']
    def __init__(self, *args, **kwargs):
        super(ComandasForm, self).__init__(*args, **kwargs)
        # Adicione qualquer personalização adicional aqui, se necessário.
        fields = [ 'descricao','mesa',]

class CaixaForm(forms.Form):
    data_inicio = forms.DateField(label="Data de início:")
    data_fim = forms.DateField(label="Data de fim:")

class FichaTecnicaForm(forms.ModelForm):
        class Meta:
            model = FichaTecnica
            fields = ['ingredientes', 'quantidade', 'unidade', 'preparo', 'observacoes']


class DateRangeForm(forms.Form):
    data_inicio = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'}),
        label='Data de início'
    )
    data_fim = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'}),
        label='Data de fim'
    )