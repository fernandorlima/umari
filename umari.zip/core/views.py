from django.shortcuts import get_object_or_404  # busca objeto se não encontrar traz p erro 404
from django.http import HttpResponse, HttpResponseBadRequest
from django.contrib import messages
from django.shortcuts import render, redirect
from .models import UserProfile, Menu, Produto, Mesas, Grupos, GrupoMenu ,ItemComanda, Comanda, Caixa, TipoMovimento,\
    FormaPgto, Saidas
from django.views import generic
from django.views.generic import FormView
from django.views.decorators.csrf import csrf_protect
from django.contrib.auth.decorators import login_required
from .forms import CadastroItemPedidoForm, MenuForm, MenuDeleteForm, MesasForm, MesasDeleteForm, ComandasForm,\
    PDVForm,CaixaForm, FichaTecnicaForm, DateRangeForm
from datetime import datetime, date, time
from django.db.models import Q, F, Sum
from django.db.models.expressions import RawSQL
from django.db.models.functions import TruncDate
from datetime import datetime
from decimal import Decimal
from django.http import JsonResponse
from django.views.generic import TemplateView
from django.views import View
from django.views.generic import ListView
from django.http import JsonResponse
from django.utils import timezone  # Ensure timezone is imported
from decimal import Decimal
from PIL import Image
import os


# Create your views here.
# viewlist class-basead que gera uma lista do modelo Menu
class MenuView(generic.ListView):
    model = Menu
    template_name = 'Menu/lista_menu.html'
    context_object_name = 'menus'  # your own name for the list as a template variable
    queryset = Menu.objects.all
    lista_menu = 'Menu/lista_menu.html'  # Specify your own template name/location


@login_required
def home(request):
    return (render(request, 'home.html'))


@csrf_protect
def index(request):
    return (render(request, 'index.html'))


@login_required
def produto(request, id):
    vproduto = Produto.objects.get(pk=id)
    prod = get_object_or_404(Produto, pk=id)
    context = {'produto': vproduto}
    return (render(request, 'produto.html', context))

######## Grupos #########################


class ProdutoListView(ListView):
    model = Produto
    template_name = 'Menu/produto_list.html'
    context_object_name = 'produtos'

    def get_queryset(self):
        # Query para buscar produtos agrupados por grupo
        produtos = Produto.objects.select_related('grupo').all().order_by('grupo__nome', 'nome')
        # Agrupar produtos por grupo
        agrupados = {}
        for produto in produtos:
            grupo_nome = produto.grupo.nome if produto.grupo else 'Sem Grupo'
            if grupo_nome not in agrupados:
                agrupados[grupo_nome] = []
            agrupados[grupo_nome].append(produto)
        return agrupados


#@login_required
def lista_grupos(request):
    # Recupera todos os objetos Grupos do banco de dados
    query = request.GET.get('q', '')

    grupos  = GrupoMenu.objects.filter(
        Q(descricao__icontains=query)).order_by('descricao')
  #  grupos = GrupoMenu.objects.all()

    # Renderiza o template
    return render(request, 'Menu/lista_grupos.html', {'grupos': grupos})

#########  Menu


def lista_menu(request, id):
 #   query = request.GET.get('q', '')

     #  menus = Menu.objects.filter(
     #   Q(descricao__icontains=query) | Q(grupomen__descricao__icontains=query)).order_by('grupomen__descricao',
      #                                                                                    'item_menu')

    menu = Menu.objects.filter(grupomen =id)
  #  return render(request, 'Menu\lista_menu.html', {'menus': menus, 'query': query})
    return render(request, 'Menu/lista_menu.html', {'menus':menu})

################################

def lista_menu01(request):
    query = request.GET.get('q', '')

    menus = Menu.objects.filter(
        Q(descricao__icontains=query) | Q(grupomen__descricao__icontains=query)).order_by('grupomen__descricao',
                                                                                          'item_menu')

    return render(request, 'Menu\lista_menu01.html', {'menus': menus, 'query': query})


####################################


def menu_detail(request, pk):
    menu = get_object_or_404(Menu, pk=pk)
    return render(request, 'menu_detail.html', {'menu': menu})


def ficha_tecnica_create(request, menu_id):
    menu = Menu.objects.get(pk=menu_id)
    if request.method == 'POST':
        form = FichaTecnicaForm(request.POST)
        if form.is_valid():
            ficha_tecnica = form.save(commit=False)
            ficha_tecnica.menu = menu
            ficha_tecnica.save()
            messages.success(request, 'Ficha Técnica cadastrada com sucesso!')
            return redirect('menu_create')
    else:
        form = FichaTecnicaForm()

    return render(request, 'FichaTecnica/ficha_tecnica_create.html', {'form': form})


@login_required
def menu_create(request):
    if request.method == 'POST':
       # form = MenuForm(request.POST)
        form = MenuForm(request.POST, request.FILES)
        if form.is_valid():
            # Crie uma instância de Menu usando o form
            menu = form.save(commit=False)

            # Associe o usuário ao menu
            if not hasattr(request.user, 'userprofile'):
                UserProfile.objects.create(user=request.user)  # Cria o UserProfile

            usuario_perfil = request.user.userprofile
            menu.usuario = usuario_perfil
            if menu.ficha_tecnica == 'S':
                # Se FT='S', abra o template de ficha técnica
                return redirect('ficha_tecnica_create', menu_id= menu.pk)

            # Salve o menu no banco de dados
            menu.imagem = request.FILES.get('imagem')  # Salva o caminho da im
            menu.save()

            # Adicione a mensagem de sucesso
            messages.success(request, 'Operação realizada com sucesso!')

            # Redirecione para a mesma página de inclusão
            return redirect('menu_create')
    else:
        form = MenuForm()

    return render(request, 'Menu/menu_create.html', {'form': form})


def menu_edit(request, pk):
    menu = get_object_or_404(Menu, pk=pk)

    if request.method == 'POST':
        form = MenuForm(request.POST, request.FILES, instance=menu)
        if form.is_valid():
            menu = form.save(commit=False)  # Não salvar ainda no banco de dados
            if 'imagem' in request.FILES:  # Verifica se um arquivo foi enviado
                menu.imagem = request.FILES['imagem']  # Define o campo de imagem no objeto do menu
            menu.save()  # Salva o objeto do menu no banco de dados
            return redirect('menu_edit', pk=menu.pk)
    else:
        form = MenuForm(instance=menu)

    return render(request, 'Menu/menu_edit.html', {'form': form})


def menu_delete(request, pk):
    menu = get_object_or_404(Menu, pk=pk)

    if request.method == 'POST':
        form = MenuDeleteForm(request.POST)
        if form.is_valid() and form.cleaned_data['confirm_delete']:
            menu.delete()
            messages.success(request, 'Operação realizada com sucesso!')
            return redirect('lista_menu')  # Substitua 'alguma_view' pela view apropriada após a exclusão
    else:
        form = MenuDeleteForm()

    return render(request, 'Menu\menu_delete.html', {'form': form, 'menu': menu})


def mapa_mesas(request):
    mesas = Mesas.objects.all()
    return render(request, 'Menu\mapa_mesas.html', {'mesas': mesas})


# pedidos

def lista_pedidos(request, mesa_id):
    try:
        # Obtém a comanda associada à mesa
        comanda = Comanda.objects.get(id=mesa_id, staus_comanda='a')
        comanda_num = comanda.id
        comanda_mesa= comanda.mesa.pk
        mesa_comanda = Mesas.objects.get(id=comanda_mesa)
        desc_mesa=mesa_comanda.descricao
        comanda_desc = comanda.descricao
        # Obtém os itens da comanda associada à mesa, incluindo informações do item_menu
        itens_comanda = ItemComanda.objects.filter(comanda=comanda)

        # Inicializa variáveis para o valor total e lista de itens com detalhes
        valor_total_comanda = 0
        itens_detalhados = []

        # Calcula o total por item e o valor total da comanda
        for item in itens_comanda:

            descricao_item_menu = item.item_menu.item_menu
            preco_item_menu = item.item_menu.preco
            quantidade_item_comanda = item.quantidade
            total_por_item = preco_item_menu * quantidade_item_comanda
            obs= item.observacao

            # Adiciona detalhes do item ao total
            itens_detalhados.append({
                'descricao': descricao_item_menu,
                'preco_unitario': preco_item_menu,
                'quantidade': quantidade_item_comanda,
                'total_por_item': total_por_item,
                'obs':obs,
            })

            # Atualiza o valor total da comanda
            valor_total_comanda += total_por_item

        return render(request, 'Menu\lista_pedido.html',
                      {'itens_detalhados': itens_detalhados,
                       'valor_total_comanda': valor_total_comanda, 'Mesa': mesa_id, 'comanda_num':comanda_num, 'comanda_desc': comanda_desc, 'mesa_desc':desc_mesa})

    except Comanda.DoesNotExist:
        return render(request, 'Menu\lista_pedido.html',
                      {'mensagem': 'Não existe comanda para esta Mesa', 'Mesa': mesa_id})


def cadastra_item_pedido(request, mesa_id):
    if request.method == 'PFOST':
        form = CadastroItemPedidoForm(request.POST)
        if form.is_valid():
            item_pedido = form.save(commit=True)

            # Verificar se a comanda já existe
            comanda, created = Comanda.objects.get_or_create(
                mesa_id=mesa_id,
                staus_comanda='a',  # Corrigi o status da comanda
                defaults={'data_cad': date.today(), 'hora_inicio': datetime.now().time()}
            )

            # Se a comanda foi criada, a mesa associada está disponível em comanda.mesa
            mesa = comanda.mesa

            # Se a comanda não foi criada, criamos a mesa agora
            if created:
                mesa, _ = Mesas.objects.get_or_create(id=mesa_id, defaults={'status_mesa': 'o'})

            # Associar o item do pedido à comanda
            item_pedido.comanda = comanda

            # Salvar o item do pedido
            item_pedido.save()

            # Atualizar status da mesa e comanda
            mesa.status_mesa = 'o'
            mesa.save()

            comanda.staus_comanda = 'a'
            comanda.save()

            return redirect('Menu/lista_pedido', mesa_id=mesa_id)
    else:
        form = CadastroItemPedidoForm()

    return render(request, 'Menu\cadastra_item_pedido.html', {'form': form, 'mesa_id': mesa_id})


def adicionar_itens_selecionados(request):
    if request.method == 'POST':
        selected_items = request.POST.getlist('selected_items')

        # Inicialize a lista de itens_pedido na sessão se ainda não existir
        if 'itens_pedido' not in request.session:
            request.session['itens_pedido'] = []

        # Adicione os itens selecionados à lista na sessão
        for menu_id in selected_items:
            menu = Menu.objects.get(id=menu_id)
            request.session['itens_pedido'].append({
                'item_menu': menu.item_menu,
                'descricao': menu.descricao,
                'preco': float(menu.preco),
                'porcao': menu.porcao,
            })

        # Redirecione para a página lista_menu01 após o processamento
        return redirect('lista_menu01')

    return JsonResponse({'error': 'Método não permitido'}, status=405)


class ListaMenu01View(View):
    template_name = 'lista_menu01.html'  # Substitua 'seu_template.html' pelo nome do seu template

    def get(self, request, *args, **kwargs):
        # Obtenha os itens do pedido da sessão
        pedidos = request.session.get('itens_pedido', [])

        # Adicione qualquer lógica adicional conforme necessário

        # Renderize a página com os itens do pedido
        return render(request, self.template_name, {'pedidos': pedidos})


class AdicionarItensSelecionadosView(View):
    template_name = 'Menu/lista_menu01.html'

    def post(self, request, *args, **kwargs):
        if 'selected_items' in request.POST:
            selected_items = request.POST.getlist('selected_items')

            # Add selected items to the session
            if 'itens_pedido' not in request.session:
                request.session['itens_pedido'] = []
            request.session['itens_pedido'].extend([
                Menu.objects.get(id=menu_id) for menu_id in selected_items
            ])

        # Render the template with updated context
        menus = Menu.objects.all()
        pedidos = request.session.get('itens_pedido', [])
        return render(request, self.template_name, {'menus': menus, 'pedidos': pedidos})

    def get(self, request, *args, **kwargs):
        menus = Menu.objects.all()
        pedidos = request.session.get('itens_pedido', [])
        return render(request, self.template_name, {'menus': menus, 'pedidos': pedidos})


class Fechar_Comanda(View):
    def post(self, request, mesa_id):
        mesa = Mesas.objects.get(id=mesa_id)
        comanda = Comanda.objects.get(mesa=mesa)
#
        # Altere o status da mesa para 'l'
        mesa.status_mesa = 'l'
        mesa.save()

        # Altere o status da comanda para 'f'
        comanda.staus_comanda = 'f'
        comanda.hora_fim = timezone.now()  # Adicione a hora de fechamento
        comanda.save()

        # Mostre a mensagem
        messages.success(request, 'Comanda fechada com sucesso')

        return redirect('lista_pedidos')  # Retornando para a página de lista de pedidos


def fecha_pedido(request, pk, pgto, fpgto):
    if not hasattr(request.user, 'userprofile'):
        UserProfile.objects.create(user=request.user)  # Cria o UserProfile

    usuario_perfil = request.user.userprofile
    mesa = Mesas.objects.get(id=pk)
    mesa.status_mesa = 'l'
    mesa.save()
    # atualiza comandas
    comanda = Comanda.objects.get(mesa=mesa, staus_comanda='a')
    comanda.staus_comanda = 'f'
    comanda.hora_fim = timezone.now()

    comanda.save()
# atualuza caixa
    caixa = Caixa()
    caixa.descricao= 'comanda'
    caixa.data = timezone.now()
    tipo_mov = TipoMovimento.objects.get(pk=2)
    caixa.tipo=  tipo_mov
    caixa.valor= pgto
    forma_pgto = FormaPgto.objects.get(pk=fpgto)
    caixa.forma_pgto_caixa= forma_pgto
    caixa.usuario =request.user.userprofile
    caixa.save()

    return redirect('lista_mesa')


def lista_pedidos_pdf(request, mesa_id):
    try:
        # Obtém a comanda associada à mesa
        comanda = Comanda.objects.get(mesa_id=mesa_id, staus_comanda='a')

        # Obtém os itens da comanda associada à mesa
        itens_comanda = ItemComanda.objects.filter(comanda=comanda)

        # Inicializa variáveis para o valor total e lista de itens com detalhes
        valor_total_comanda = 0
        itens_detalhados = []

        # Calcula o total por item e o valor total da comanda
        for item in itens_comanda:
            descricao_item_menu = item.item_menu.item_menu
            preco_item_menu = item.item_menu.preco
            quantidade_item_comanda = item.quantidade
            total_por_item = preco_item_menu * quantidade_item_comanda

            # Adiciona detalhes do item ao total
            itens_detalhados.append({
                'descricao': descricao_item_menu,
                'preco_unitario': preco_item_menu,
                'quantidade': quantidade_item_comanda,
                'total_por_item': total_por_item,
            })

            # Atualiza o valor total da comanda
            valor_total_comanda += total_por_item
        itens_detalhados.append({'total_comanda': valor_total_comanda})
        colunas = 40
        imprimir_lista(str(itens_detalhados).format(*['{:<20}'.format(key) for key in itens_detalhados[0].keys()]),
                       "lpt")
        return render(request, 'Menu\lista_pedido.html',
                      {'itens_detalhados': itens_detalhados,
                       'valor_total_comanda': valor_total_comanda, 'Mesa': mesa_id})

    except Comanda.DoesNotExist:
        return render(request, 'Menu\lista_pedido.html',
                      {'mensagem': 'Não existe comanda para esta Mesa', 'Mesa': mesa_id})


################################################################################


def imprimir_itens_detalhados(request):
        try:
            # Obtém a comanda associada à mesa
         #  comandas_abertas = Comanda.objects.filter(staus_comanda='a')

         #  for comandas in comandas_abertas:
                # Filtrar itens de comanda usando Q object
        #        comanda_num = comandas.id
        #        mesa = comandas.mesa_id
                itens_comanda = ItemComanda.objects.filter(status='Preparo')
                 #  Q(comanda__in=comandas_abertas) & Q(status ='Preparo'))# Filtrar por comanda vinculada às comandas abertas
                  #  Q(comanda__in=comandas_abertas) & Q(status ='Preparo'))# Filtrar por comanda vinculada às comandas abertas

                # Inicializa variáveis para o valor total e lista de itens com detalhes
                valor_total_comanda = 0
                itens_detalhados = []

                # Calcula o total por item e o valor total da comanda
                for item in itens_comanda:
                    comanda=item.comanda_id
                    descricao_item_menu= item.descicao_item
                    item_pedido= item.item_menu.id
                    descricao_item_menu = item.item_menu.item_menu
                    observacao= item.observacao
                    status = item.status
                    preco_item_menu = item.item_menu.preco
                    quantidade_item_comanda = item.quantidade
                    total_por_item = preco_item_menu * quantidade_item_comanda
                    # Adiciona detalhes do item ao total
                    itens_detalhados.append({
                        'comanda_num':comanda,
                        'item_pedido':item_pedido,
                        'descricao': descricao_item_menu,
                        'preco_unitario': preco_item_menu,
                        'quantidade': quantidade_item_comanda,
                        'obs':observacao,
                        'status':status,
                        'total_por_item': total_por_item,
                    })

                    # Atualiza o valor total da comanda
                    valor_total_comanda += total_por_item
                itens_detalhados.append({'total_comanda': valor_total_comanda})

                # Converte a lista de itens detalhados em uma string
                itens_detalhados_str = " ".join([str(item) for item in itens_detalhados])
                #
                #      "response = HttpResponse(content_type='application/pdf')
                #     response['Content-Disposition'] = 'attachment; filename="itens_detalhados.pdf"'
                #     response.write(itens_detalhados_str.encode())  # Escrevi diretamente na resposta
                #     return response

                context = {'itens': itens_detalhados,  'descricao': descricao_item_menu}

                return render(request, 'Menu/imprimir_comanda.html', context)


        except Comanda.DoesNotExist:
                return render(request, 'Menu\lista_pedido.html',
                              {'mensagem': 'Não existe comanda para esta Mesa', 'Mesa': comanda_num})


def imprimir_lista(lista):
    colunas = 40
    os.system("lpr -l -P lpt1 {}".format(" ".join([str(item) for item in lista])))


#################### Mesas
@login_required()
def cadastra_mesa(request):
    if request.method == 'POST':
        form = MesasForm(request.POST)
        if form.is_valid():
            # salva os dados no bd

            mesa = form.save()
            mesa.status_mesa = 'o'
            ultima_mesa  = mesa.pk
            mesa_id= ultima_mesa
            hora_atual = datetime.now()
            hora_fim= "00:00:00"
            comanda, created = Comanda.objects.get_or_create(
                mesa_id=mesa_id,
                staus_comanda='a',
                defaults={'data_cad': date.today(), 'hora_inicio': datetime.now().time()}
            )
            # Associe o usuário ao menu
            if not hasattr(request.user, 'userprofile'):
                UserProfile.objects.create(user=request.user)  # Cria o UserProfile

            usuario_perfil = request.user.userprofile
            #    mesa.usuario = usuario_perfil

            # Salve o menu no banco de dados
            mesa.save()

            # Adicione a mensagem de sucesso
            messages.success(request, 'Operação realizada com sucesso!')
            return redirect('cadastra_mesa')
        # Redirecione para a mesma página
        else:
            return redirect('Menu/cadastra_mesa.html')
    else:
        form = MesasForm()
        return render(request, 'Menu/cadastra_mesa.html', {'form': form})


def lista_mesa(request):
    lista_mesas = Mesas.objects.all()

    context = {'mesas': lista_mesas}
    return (render(request, 'Menu/lista_mesa.html', context))


def mesa_edit(request, id):
    mesa = get_object_or_404(Mesas, id=id)

    if request.method == 'POST':
        form = MesasForm(request.POST, instance=mesa)
        if form.is_valid():
            mesa = form.save()
            return redirect('mesa_edit', id=mesa.id)  # Correção aqui
    else:
        form = MesasForm(instance=mesa)

    return render(request, 'Menu/mesa_edit.html', {'form': form})


def mesa_delete(request, id):
    mesa = get_object_or_404(Mesas, id=id)

    if request.method == 'POST':
        form = MesasDeleteForm(request.POST)
        if form.is_valid() and form.cleaned_data['confirm_delete']:
            mesa.delete()
            messages.success(request, 'Operação realizada com sucesso!')
            return redirect('lista_mesa')  # Substitua 'alguma_view' pela view apropriada após a exclusão
    else:
        form = MesasDeleteForm()
    return render(request, 'Menu\mesa_delete.html', {'form': form, 'mesa': mesa})


def mesa_mudar(request, id):
    mesa = get_object_or_404(Mesas, id=id)
    if request.method == 'POST':
        form = MesasForm(request.POST, instance=mesa)
        if form.is_valid():
            mesa = form.save()
            return redirect('mesa_mudar', id=mesa.id)  # Correção aqui
    else:
        form = MesasForm(instance=mesa)

    return render(request, 'Menu/mesa_mudar.html', {'form': form, 'mesa': mesa})


def lista_cardapio(request, id):
    if not hasattr(request.user, 'userprofile'):
        UserProfile.objects.create(user=request.user)  # Cria o UserProfile

    usuario_perfil = request.user.userprofile
   # mesa = Mesas.objects.get(id=id)
   # mesa_id = mesa.id

    comanda = Comanda.objects.get(id=id, staus_comanda='a')
    mesa_num = comanda.mesa
    descricao = comanda.descricao
    quant = 1
    # comanda_id = comanda.pk
    query = request.GET.get('q', '')

    menus = Menu.objects.filter(
        Q(descricao__icontains=query) | Q(grupomen__descricao__icontains=query)).order_by('grupomen__descricao',
                                                                                          'item_menu')

    return render(request, 'Menu\lista_cardapio.html ', {'menus': menus, 'mesa': id, 'mesa_num': mesa_num, 'descricao': descricao})


def atualiza_itens_pedido(request, mesa_id):
    if request.method == 'POST':
        selected_items = request.POST.getlist('selected_items')
        mesa_id = request.POST.get('mesa_id')

        for item_id in selected_items:
            menu = Menu.objects.get(id=item_id)
            quantidade = int(request.POST.get(f'quantidade_{item_id}', 1))

            item_comanda, created = ItemComanda.objects.get_or_create(comanda_mesa_id=mesa_id, item_menu=menu)

            item_comanda.quantidade += quantidade if not created else quantidade
            item_comanda.save()

    # Corrigindo a passagem do valor de mesa_id no redirecionamento
    return redirect('Menu/lista_pedido', mesa_id=mesa_id)


###########################################


def novo_item(request, menu_id, comanda ):
    if request.method != 'POST':
        return HttpResponse("Método de requisição inválido")
    quantidade_str = request.POST.get('quantidade2','')  # Defina um valor padrão se necessário
    observa = request.POST.get('obs','')
    print('quant>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>',quantidade_str )
    if quantidade_str :

       try:
         quantidade = int(quantidade_str)  # Converta para um inteiro, se necessário
       except ValueError:
            redirect('lista_cardapio')
            # Lida com o caso em que a string não pode ser convertida para um inteiro
          #   quantidade = quantidade_str # Defina um valor padrão



           # quantidade = 1  # Se quantidade_str estiver vazio, defina um valor padrão
    else:
        return redirect('lista_cardapio', comanda)

    # Verificar se a mesa existe


    # Verificar se a comanda já existe

    comanda_atual = Comanda.objects.get(id=comanda, staus_comanda='a')
    num_comanda = comanda_atual.id


    # Atualiza o status da mesa apenas se a comanda foi criada


    # Adiciona o item ao ItemComanda
    menu = get_object_or_404(Menu, pk=menu_id)


    item_comanda = ItemComanda.objects.create(
            comanda=comanda_atual,
            item_menu=menu,
            quantidade=int(quantidade_str),
            status='Preparo',
            observacao = observa,
            descicao_item = menu.item_menu
        )
    item_comanda.save()
    messages.success(request, "Item adicionado à comanda com sucesso.")
    # Mensagens de feedback
    messages.success(request, "Item adicionado à comanda.")
    #########################################
    #      atualiza estoque
    ###########################################

    produto_menu = Menu.objects.get(pk=menu_id)
    codigo_produto= produto_menu.id_produto_id
    if produto_menu.ficha_tecnica== 'N':
       saida_estoque(codigo_produto, quantidade)
        ##########################################

########################3
# se houver  ficha tecnica
# obter a ficha efazer  loop  com
# todos os produtos da ficha  dando baixa no estoque
 #########################################################


    return redirect('lista_pedido',mesa_id=comanda)

def saida_estoque(codigo_produto, quantidade):

    try:
        produto = Produto.objects.get(id=codigo_produto)
    except Produto.DoesNotExist:
        raise ValueError(f"Produto com código {codigo_produto} não encontrado.")
    volumes = produto.quantidade
    quant = produto.estoque_atual
    volumes_unidade = produto.quant_unidade
    quant -= quantidade
    print('codgio >>',codigo_produto)
    print('volumes >>', volumes)
    print('estoque atual', quant)
    if quant < 0:
        raise ValueError(f"Quantidade de saída ({quantidade}) excede o estoque disponível ({produto.quant_unidade}).")
    if divmod(quant,volumes_unidade):
        volumes -=1
        produto.quantidade=volumes
    produto.tipo_saida='1'
    produto.estoque_atual = quant
    produto.save()

    # Register output
    saidas = Saidas.objects.create(
        produto=produto,
        saida=quantidade,
        data_saida=date.today()
    )
    saidas.save()


def lista_comandas(request):
    lista_comandas = Comanda.objects.filter(staus_comanda='a')

    # Convertendo os campos de data para strings
    comandas_formatadas = []
    for comanda in lista_comandas:
    #    data_cad_str = comanda.data_cad.strftime("%Y-%m-%d")
    #    hora_inicio_str = comanda.hora_inicio.strftime("%H:%M:%S")
     #   hora_fim_str = comanda.hora_fim.strftime("%H:%M:%S")

        comanda_formatada = {
            'id': comanda.id,
            'descricao': comanda.descricao,
            'mesa': comanda.mesa,
            'usuario': comanda.usuario,
            'staus_comanda': comanda.staus_comanda

        }

        comandas_formatadas.append(comanda_formatada)

    context = {'comandas_abertas': comandas_formatadas}
    return render(request, 'Menu/lista_comandas.html', context)

@login_required()
def cadastra_comandas(request):
    if request.method == 'POST':
        form = ComandasForm(request.POST)
        if form.is_valid():
            # salva os dados no bd
            comanda = form.save(commit=False)
            comanda.staus_comanda = 'a'
            comanda.data_cad = datetime.today()

            comanda.hora_inicio = datetime.now()
            comanda.hora_fim = "00:00:00"

            # Associe o usuário ao menu
            if not hasattr(request.user, 'userprofile'):
                UserProfile.objects.create(user=request.user)  # Cria o UserProfile

            usuario_perfil = request.user.userprofile            #    mesa.usuario = usuario_perfil
            comanda.usuario=usuario_perfil
            # Salve o menu no banco de dados
            comanda.save()
            nova_comanda = comanda.pk
            mesa_comanda = comanda.mesa
            print('mesa comanda .>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>', mesa_comanda)
            mesa = Mesas.objects.get(descricao=mesa_comanda)
            print('mesa id>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>', mesa.id)
            mesa.status_mesa='o'
            mesa.save()

            # Adicione a mensagem de sucesso
            messages.success(request, 'Operação realizada com sucesso!')
            #return redirect('comandas')
        #    return redirect('lista_pedido', mesa_id=nova_comanda)
            return redirect('lista_cardapio',id=nova_comanda)

        # Redirecione para a mesma página
        else:
            return redirect('Menu/lista_pedidos.html')
    else:
        form = ComandasForm()
        return render(request, 'Menu/cadastra_comandas.html', {'form': form})


def MesasAbertas(request):
        # Recupera todos os objetos Grupos do banco de dados
          query = request.GET.get('q', '')
          if query:
              comandas = Comanda.objects.filter(Q(staus_comanda='a') &
              Q(descricao__icontains=query) | Q(mesa__descricao=query)).order_by('descricao')

          else:
              comandas = Comanda.objects.filter(staus_comanda='a')
          ddados_comanda=[]
        # Renderiza o template
          print ('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>',comandas.query)
          return render(request, 'Menu/mesas_abertas_list.html', {'comandas':comandas})

    ############# PDV

def pdv_view(request):
    if request.method == 'POST':
        form = PDVForm(request.POST)
        if form.is_valid():
            comanda = form.cleaned_data['comanda_selecionada']
            forma_pagamento = form.cleaned_data['forma_pagamento']
            valor_pago = form.cleaned_data['valor_pago']

            # Lógica para calcular o valor total dos itens em ItemComanda
            itens_comanda = comanda.itemcomanda_set.all()
            valor_total = sum(item.item_menu.preco * item.quantidade for item in itens_comanda)

            # Lógica para calcular o troco, se a forma de pagamento for dinheiro
            troco = 0.0
            if forma_pagamento.nome == 'Dinheiro':
                troco = valor_pago - valor_total

            # Lógica para imprimir o recibo, atualizar o caixa, etc.

            # Exemplo de atualização do caixa
            Caixa.objects.create(valor=valor_total, tipo=TipoMovimento.objects.get(nome='Entrada'), descricao='Venda', forma_pgto_caixa=forma_pagamento, data=timezone.now(), usuario=request.user)

            return render(request, 'Menu/pdv_template.html', {'form': form, 'itens_comanda': itens_comanda, 'valor_total': valor_total})

    else:
        form = PDVForm()

    return render(request, 'Menu/pdv_template.html', {'form': form})

def detalhes_comanda_view(request, comanda_id):
    comanda = get_object_or_404(Comanda, id=comanda_id)
    itens_comanda = comanda.itemcomanda_set.all()

    valor_total = sum(item.item_menu.preco * item.quantidade for item in itens_comanda)

    return render(request, 'Menu/'
                           'detalhes_comanda_template.html', {'comanda': comanda, 'itens_comanda': itens_comanda, 'valor_total': valor_total})



def Fechar_Pedidos(request, mesa_id):
    try:

        # Obtém a comanda associada à mesa
        comanda = Comanda.objects.get(id=mesa_id, staus_comanda='a')
        comanda_num= comanda.id

        # Obtém os itens da comanda associada à mesa, incluindo informações do item_menu
        itens_comanda = ItemComanda.objects.filter(comanda=comanda)

        # Inicializa variáveis para o valor total e lista de itens com detalhes
        valor_total_comanda = 0
        itens_detalhados = []

        # Calcula o total por item e o valor total da comanda
        for item in itens_comanda:

            descricao_item_menu = item.item_menu.item_menu
            preco_item_menu = item.item_menu.preco
            quantidade_item_comanda = item.quantidade
            total_por_item = preco_item_menu * quantidade_item_comanda

            # Adiciona detalhes do item ao total
            itens_detalhados.append({
                'descricao': descricao_item_menu,
                'preco_unitario': preco_item_menu,
                'quantidade': quantidade_item_comanda,
                'total_por_item': total_por_item,
            })

            # Atualiza o valor total da comanda
            valor_total_comanda += total_por_item
           # forma de pagamento
            pgto = FormaPgto.objects.all()

        return render(request, 'Menu/fechar_comandas.html',
                      {'itens_detalhados': itens_detalhados,
                       'valor_total_comanda': valor_total_comanda, 'Mesa': mesa_id, 'comanda_num':comanda_num, 'formapgto':pgto})

    except Comanda.DoesNotExist:
        return render(request, 'Menu/fechar_comandas.html',
                      {'mensagem': 'Não existe comanda para esta Mesa', 'Mesa': mesa_id})

def Finaliza_Comanda(request, mesa_id):
    if not hasattr(request.user, 'userprofile'):
        UserProfile.objects.create(user=request.user)  # Cria o UserProfile

    usuario_perfil = request.user.userprofile
    if request.method == 'POST':
        pagamento = request.POST.get('pagamento')
        pgto =pagamento.replace(",", ".")

        formapgto = request.POST.get('formapgto')
        # O parâmetro comanda_num pode ser obtido diretamente do pk da url
        comanda = Comanda.objects.get(id=mesa_id, staus_comanda='a')
        mesa1 = comanda.mesa_id
        mesa = Mesas.objects.get(pk=mesa1)
        if mesa.descricao != 'Balcão':
           mesa.status_mesa = 'l'
           mesa.save()
        # atualiza comandas
        comanda = Comanda.objects.get(id=mesa_id, staus_comanda='a')
        comanda.staus_comanda = 'f'
        comanda.hora_fim = timezone.now()
        comanda.total_comanda=pgto

        comanda.save()
        # atualuza caixa
        caixa = Caixa()
        caixa.descricao = 'comanda'
        caixa.data = datetime.today()
        tipo_mov = TipoMovimento.objects.get(pk=1)
        caixa.tipo = tipo_mov
        caixa.valor = Decimal(pgto)
        forma_pgto = FormaPgto.objects.get(pk=formapgto)
        caixa.forma_pgto_caixa = forma_pgto
        caixa.usuario = usuario_perfil #request.user.userprofile
        caixa.save()
        return redirect('comandas')
    else:
        # Caso não seja POST, retorne algum erro ou redirecionamento
        return HttpResponseBadRequest('Requisição inválida')
    return redirect('comandas')

def lista_comandas_mesa(request, mesa_id):
    #try:
       comandas = Comanda.objects.get(mesa_id=mesa_id, staus_comanda = 'a')
       comanda_mesa =comandas.id
       print('comanda mesa>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>',comanda_mesa)
       mesa_comanda=Mesas.objects.get(id=mesa_id)
       mesa_desc = mesa_comanda.descricao
       context = {'comandas': comandas, 'mesa_comanda':mesa_desc}  # Pass the list of comandas to the template

     #  return render(request, 'Menu/lista_comandas_mesa.html', context)
       return (lista_pedidos(request, mesa_id=comanda_mesa))
  #  except Comanda.DoesNotExist:
  #     return (redirect('comandas'))#render(request, 'Menu\lista_comandas_mesa.html',context)





class CaixaEntreDatasView(FormView):
    template_name = 'Menu/consulta_caixa_periodo.html'
    form_class = CaixaForm  # Update the form class

    def post(self, request, *args, **kwargs):
        form = self.form_class(request.POST)
        if form.is_valid():
            data_inicio = form.cleaned_data['data_inicio']
            data_fim = form.cleaned_data['data_fim']

            # Consulta para buscar os caixas dentro do intervalo de datas
            caixas = Caixa.objects.filter(
                data__range=(data_inicio, data_fim)
            ).annotate(
                data_trunc=TruncDate('data'),
                forma_pgto_descricao=F('forma_pgto_caixa__nome'),  # Adicionando a descrição da forma de pagamento
                descricao_movimento=F('tipo__nome')
            ).values('data_trunc', 'tipo', 'forma_pgto_descricao', 'descricao_movimento').annotate(
                total=Sum('valor')
            ).order_by('data_trunc')

            # Inicializar dicionário para totalizar por forma de pagamento
            total_por_forma_pgto = {}

            # Percorrer caixas e atualizar totais por forma de pagamento
            for caixa in caixas:
                forma_pgto_descricao = caixa['forma_pgto_descricao']
                if forma_pgto_descricao not in total_por_forma_pgto:
                    total_por_forma_pgto[forma_pgto_descricao] = caixa['total']
                else:
                    total_por_forma_pgto[forma_pgto_descricao] += caixa['total']

            # Calculando os totais de entrada, saída e saldo
            total_entrada = sum(caixa['total'] for caixa in caixas if caixa['tipo'] == 1)
            total_saida = sum(caixa['total'] for caixa in caixas if caixa['tipo'] == 2)
            saldo = total_entrada - total_saida

            context = {
                'data1': data_inicio,
                'data2': data_fim,
                'caixas': caixas,
                'total_entrada': total_entrada,
                'total_saida': total_saida,
                'saldo': saldo,
                'total_por_forma_pgto': total_por_forma_pgto,
            }

            return render(request, 'Menu/lista_caixa_periodo.html', context)




def altera_status_pedido(request):
  """
  Função para alterar o status de um item na comanda para "Pronto".

  Recebe uma solicitação POST com o valor `item_atual` (ID do item) e atualiza o status do item correspondente no banco de dados.
  """
  if request.method != 'POST':
      print('estou aqui1')
      return HttpResponseBadRequest('Requisição inválida. Utilize o método POST.')

  item_atual = request.POST.get('item_pedido')
  comanda_pedido = request.POST.get('comanda_pedido')
  print('comanda>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>', comanda_pedido)
  print('Item atual.........................................................................', item_atual)

  print('item atual 2...............................................................................', item_atual)

  item_pedido = ItemComanda.objects.get(item_menu_id=item_atual,comanda_id=comanda_pedido)
  item_pedido.status = 'Pronto'  # Atualiza o status para "1" (Pronto)
  item_pedido.save()

  # Redireciona para a página da lista de pedidos da comanda correspondente
  return render(request,'Menu/imprimi_comanda.html')







def pega_quantidade(request):
    # Carregue o contexto (se necessário)
    print('passei aqui>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')
    context = {}

    # Renderize o template e retorne o resultado
    return render(request, 'Menu/pega_quant.html', context)


def comandas_por_periodo(request):
    if request.method == 'POST':
        form = DateRangeForm(request.POST)
        if form.is_valid():
            data_inicio = form.cleaned_data['data_inicio']
            data_fim = form.cleaned_data['data_fim']

            comandas = Comanda.objects.filter(data_cad__range=[data_inicio, data_fim])
            total = comandas.aggregate(Sum('total_comanda'))['total_comanda__sum'] or 0

            return render(request, 'Menu/lista_comandas_por_periodo.html', {
                'form': form,
                'comandas': comandas,
                'total': total,
                'data_inicio': data_inicio,
                'data_fim': data_fim
            })
        else:
            # Se o formulário não for válido, renderize o formulário novamente com os erros
            return render(request, 'Menu/comandas_por_periodo.html', {'form': form})
    else:
        form = DateRangeForm()
        return render(request, 'Menu/comandas_por_periodo.html', {'form': form})





def item_comandas_por_periodo(request):
    if request.method == 'POST':
        form = DateRangeForm(request.POST)
        if form.is_valid():
            data_inicio = form.cleaned_data['data_inicio']
            data_fim = form.cleaned_data['data_fim']

            # Verificação dos valores de entrada
            print(f"Data Início: {data_inicio}, Data Fim: {data_fim}")

            item_comandas = ItemComanda.objects.filter(
                Q(comanda__data_cad__gte=data_inicio) & Q(comanda__data_cad__lte=data_fim)
            ).select_related('item_menu')

            # Verificação dos itens filtrados
            print(f"Itens Comanda Filtrados: {item_comandas}")

            total_por_item = item_comandas.values('item_menu_id', 'descicao_item', 'item_menu__preco').annotate(
                quantidade_total=Sum('quantidade'),
                valor_total=Sum(F('quantidade') * F('item_menu__preco'))
            )

            # Calcular o total geral
            total_geral = total_por_item.aggregate(total_geral=Sum('valor_total'))['total_geral'] or 0

            # Verificação do resultado da agregação
            print(f"Total por Item: {total_por_item}")
            print(f"Total Geral: {total_geral}")

            return render(request, 'Menu/lista_item_comandas_por_periodo.html', {
                'form': form,
                'total_por_item': total_por_item,
                'total_geral': total_geral,
                'data_inicio': data_inicio,
                'data_fim': data_fim
            })
        else:
            return render(request, 'Menu/consulta_item_comandas_periodo.html', {'form': form})
    else:
        form = DateRangeForm()
        return render(request, 'Menu/consulta_item_comandas_periodo.html', {'form': form})








